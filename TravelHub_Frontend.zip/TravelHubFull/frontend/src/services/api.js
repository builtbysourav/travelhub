// ============================================================
// TRAVELHUB — API SERVICE LAYER
// Connects React frontend to FastAPI backend
// ============================================================

const BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:8000";

// ── Token helpers ─────────────────────────────────────────────────────────────
export const getToken = () => localStorage.getItem("th_token");
export const setToken = (t) => localStorage.setItem("th_token", t);
export const clearToken = () => localStorage.removeItem("th_token");

// ── Base fetch with auth header ───────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  try {
    const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: res.statusText }));
      throw new Error(err.detail || "Request failed");
    }
    return res.json();
  } catch (e) {
    console.warn(`API error [${path}]:`, e.message);
    throw e;
  }
}

// ── AUTH ──────────────────────────────────────────────────────────────────────
export const authAPI = {
  register: (data) => apiFetch("/api/auth/register", { method: "POST", body: JSON.stringify(data) }),
  login:    (data) => apiFetch("/api/auth/login",    { method: "POST", body: JSON.stringify(data) }),
  me:       ()     => apiFetch("/api/auth/me"),
};

// ── DESTINATIONS ──────────────────────────────────────────────────────────────
export const destinationsAPI = {
  getAll:  (params = {}) => apiFetch("/api/destinations?" + new URLSearchParams(params)),
  getOne:  (id)          => apiFetch(`/api/destinations/${id}`),
  create:  (data)        => apiFetch("/api/destinations", { method: "POST", body: JSON.stringify(data) }),
};

// ── AGENCIES ──────────────────────────────────────────────────────────────────
export const agenciesAPI = {
  getAll:  (params = {}) => apiFetch("/api/agencies?" + new URLSearchParams(params)),
  getOne:  (id)          => apiFetch(`/api/agencies/${id}`),
  create:  (data)        => apiFetch("/api/agencies",    { method: "POST", body: JSON.stringify(data) }),
  update:  (id, data)    => apiFetch(`/api/agencies/${id}`, { method: "PUT",  body: JSON.stringify(data) }),
};

// ── PACKAGES ──────────────────────────────────────────────────────────────────
export const packagesAPI = {
  getAll:  (params = {}) => apiFetch("/api/packages?" + new URLSearchParams(params)),
  getOne:  (id)          => apiFetch(`/api/packages/${id}`),
  create:  (data)        => apiFetch("/api/packages",    { method: "POST",   body: JSON.stringify(data) }),
  update:  (id, data)    => apiFetch(`/api/packages/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete:  (id)          => apiFetch(`/api/packages/${id}`, { method: "DELETE" }),
  trackView: (id)        => apiFetch(`/packages/${id}/view`, { method: "POST" }),
  socialProof: (id, date) => apiFetch(`/packages/${id}/social-proof${date ? "?departure_date=" + date : ""}`),
};

// ── BOOKINGS ──────────────────────────────────────────────────────────────────
export const bookingsAPI = {
  create:  (data)        => apiFetch("/api/bookings",    { method: "POST", body: JSON.stringify(data) }),
  getAll:  (params = {}) => apiFetch("/api/bookings?" + new URLSearchParams(params)),
  getOne:  (id)          => apiFetch(`/api/bookings/${id}`),
  cancel:  (id)          => apiFetch(`/api/bookings/${id}/cancel`, { method: "PUT" }),
};

// ── REVIEWS ───────────────────────────────────────────────────────────────────
export const reviewsAPI = {
  getAll: (agencyId) => apiFetch(`/api/reviews?agency_id=${agencyId}`),
  create: (data)     => apiFetch("/api/reviews", { method: "POST", body: JSON.stringify(data) }),
};

// ── MESSAGES / CHAT ───────────────────────────────────────────────────────────
export const messagesAPI = {
  getAll: (agencyId) => apiFetch(`/api/messages?agency_id=${agencyId}`),
  send:   (data)     => apiFetch("/api/messages", { method: "POST", body: JSON.stringify(data) }),
};

// ── AI SEARCH ─────────────────────────────────────────────────────────────────
export const aiSearchAPI = {
  search: (query) => apiFetch("/ai/search", { method: "POST", body: JSON.stringify({ query }) }),
};

// ── TRAVEL DNA QUIZ ───────────────────────────────────────────────────────────
export const dnaAPI = {
  getQuestions: ()     => apiFetch("/dna/questions"),
  submitQuiz:   (data) => apiFetch("/dna/quiz", { method: "POST", body: JSON.stringify(data) }),
};

// ── TRIP ROOM (Group Trip Planner) ────────────────────────────────────────────
export const tripRoomAPI = {
  create:     (data)             => apiFetch("/trip/create",              { method: "POST", body: JSON.stringify(data) }),
  join:       (code)             => apiFetch(`/trip/${code}/join`,        { method: "POST" }),
  getRoom:    (code)             => apiFetch(`/trip/${code}`),
  addPackage: (code, packageId)  => apiFetch(`/trip/${code}/add-package`, { method: "POST", body: JSON.stringify({ package_id: packageId }) }),
  vote:       (code, packageId)  => apiFetch(`/trip/${code}/vote`,        { method: "POST", body: JSON.stringify({ package_id: packageId }) }),
  close:      (code)             => apiFetch(`/trip/${code}/close`,       { method: "PATCH" }),
  wsUrl:      (code)             => `${BASE_URL.replace("http", "ws")}/trip/${code}/ws`,
};

// ── SOCIAL PROOF ──────────────────────────────────────────────────────────────
export const socialProofAPI = {
  trackView:  (id)        => apiFetch(`/packages/${id}/view`, { method: "POST" }),
  getSignals: (id, date)  => apiFetch(`/packages/${id}/social-proof${date ? "?departure_date=" + date : ""}`),
};

// ── OFFLINE CACHE ─────────────────────────────────────────────────────────────
export const cache = {
  set: (key, data) => {
    try { localStorage.setItem("th_" + key, JSON.stringify({ data, ts: Date.now() })); } catch {}
  },
  get: (key, maxAgeMs = 5 * 60 * 1000) => {
    try {
      const raw = localStorage.getItem("th_" + key);
      if (!raw) return null;
      const { data, ts } = JSON.parse(raw);
      if (Date.now() - ts > maxAgeMs) return null;
      return data;
    } catch { return null; }
  },
};

// ── Smart fetch with cache fallback ──────────────────────────────────────────
export async function fetchWithCache(key, fetcher, maxAgeMs) {
  const cached = cache.get(key, maxAgeMs);
  if (cached) return { data: cached, fromCache: true };
  try {
    const data = await fetcher();
    cache.set(key, data);
    return { data, fromCache: false };
  } catch (e) {
    const stale = cache.get(key, Infinity);
    if (stale) return { data: stale, fromCache: true, offline: true };
    throw e;
  }
}
