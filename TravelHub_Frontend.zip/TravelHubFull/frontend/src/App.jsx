import { useState, useEffect, useRef, useContext, createContext, useCallback } from "react";
import {
  authAPI, destinationsAPI, agenciesAPI, packagesAPI,
  bookingsAPI, reviewsAPI, messagesAPI, aiSearchAPI,
  dnaAPI, tripRoomAPI, socialProofAPI,
  fetchWithCache, getToken, setToken, clearToken
} from "./services/api";

// ─── GLOBAL STYLES ────────────────────────────────────────────────────────────

// Image fallback helper - attach to all <img> tags
const imgFallback = (e, label="") => {
  e.target.onerror = null;
  const canvas = document.createElement("canvas");
  canvas.width = 800; canvas.height = 500;
  const ctx = canvas.getContext("2d");
  const colors = ["#C4622D","#3D6B20","#4A90A4","#C9963A","#8B5E3C","#2D5016"];
  ctx.fillStyle = colors[Math.abs(label.charCodeAt(0)||65) % colors.length];
  ctx.fillRect(0,0,800,500);
  ctx.fillStyle = "rgba(255,255,255,0.15)";
  ctx.fillRect(0,200,800,100);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 32px serif";
  ctx.textAlign = "center";
  ctx.fillText(label || "📍 India", 400, 260);
  e.target.src = canvas.toDataURL();
};

const GlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=DM+Sans:wght@300;400;500;600&family=DM+Serif+Display:ital@0;1&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --cream: #F5EFE6;
      --warm-white: #FBF8F3;
      --sand: #E8DFD0;
      --brown-dark: #2C1810;
      --brown-mid: #5C3317;
      --brown-light: #8B5E3C;
      --terracotta: #C4622D;
      --terracotta-light: #E8845A;
      --forest: #2D5016;
      --forest-mid: #3D6B20;
      --mint: #7BAE6E;
      --gold: #C9963A;
      --gold-light: #F0C05A;
      --sky: #4A90A4;
      --risk-low: #2D9E6B;
      --risk-mid: #E8A020;
      --risk-high: #D44333;
      --shadow-sm: 0 2px 8px rgba(44,24,16,0.08);
      --shadow-md: 0 4px 20px rgba(44,24,16,0.12);
      --shadow-lg: 0 8px 40px rgba(44,24,16,0.18);
      --radius-sm: 8px;
      --radius-md: 16px;
      --radius-lg: 24px;
      --radius-xl: 40px;
      --font-display: 'Playfair Display', serif;
      --font-serif: 'DM Serif Display', serif;
      --font-body: 'DM Sans', sans-serif;
    }

    html { scroll-behavior: smooth; }

    body {
      font-family: var(--font-body);
      background: var(--warm-white);
      color: var(--brown-dark);
      overflow-x: hidden;
    }

    ::selection { background: var(--gold-light); color: var(--brown-dark); }
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: var(--cream); }
    ::-webkit-scrollbar-thumb { background: var(--brown-light); border-radius: 3px; }

    /* Animations */
    @keyframes fadeUp { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
    @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
    @keyframes shimmer { 0%,100%{opacity:0.4} 50%{opacity:0.8} }
    @keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.05)} }
    @keyframes spin { to { transform: rotate(360deg); } }
    @keyframes slideIn { from { transform:translateX(-100%); opacity:0; } to { transform:translateX(0); opacity:1; } }
    @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }

    .fade-up { animation: fadeUp 0.6s ease forwards; }
    .fade-in { animation: fadeIn 0.4s ease forwards; }

    /* Button base */
    .btn {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 12px 24px; border-radius: var(--radius-md);
      font-family: var(--font-body); font-weight: 500; font-size: 15px;
      cursor: pointer; border: none; transition: all 0.25s ease;
      text-decoration: none; white-space: nowrap;
    }
    .btn-primary {
      background: var(--forest-mid); color: #fff;
      box-shadow: 0 4px 14px rgba(45,80,22,0.3);
    }
    .btn-primary:hover { background: var(--forest); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(45,80,22,0.4); }
    .btn-secondary {
      background: var(--terracotta); color: #fff;
      box-shadow: 0 4px 14px rgba(196,98,45,0.3);
    }
    .btn-secondary:hover { background: #A8521F; transform: translateY(-2px); }
    .btn-outline {
      background: transparent; color: var(--brown-mid);
      border: 2px solid var(--brown-light);
    }
    .btn-outline:hover { background: var(--sand); }
    .btn-ghost { background: rgba(255,255,255,0.15); color: #fff; border: 1px solid rgba(255,255,255,0.3); }
    .btn-ghost:hover { background: rgba(255,255,255,0.25); }
    .btn-sm { padding: 8px 16px; font-size: 13px; }
    .btn-lg { padding: 16px 32px; font-size: 17px; }

    /* Card */
    .card {
      background: #fff; border-radius: var(--radius-lg);
      box-shadow: var(--shadow-sm); overflow: hidden;
      transition: all 0.3s ease;
    }
    .card:hover { box-shadow: var(--shadow-lg); transform: translateY(-4px); }

    /* Tag/Badge */
    .badge {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 10px; border-radius: 99px;
      font-size: 12px; font-weight: 500;
    }
    .badge-green { background: #E8F5E3; color: var(--forest-mid); }
    .badge-gold { background: #FFF3DB; color: #9A6A00; }
    .badge-terra { background: #FDE8DE; color: var(--terracotta); }
    .badge-blue { background: #E3F0F5; color: var(--sky); }

    /* Input */
    .input {
      width: 100%; padding: 12px 16px; border-radius: var(--radius-sm);
      border: 2px solid var(--sand); background: var(--warm-white);
      font-family: var(--font-body); font-size: 15px; color: var(--brown-dark);
      outline: none; transition: border-color 0.2s;
    }
    .input:focus { border-color: var(--forest-mid); }
    .input::placeholder { color: var(--brown-light); }

    /* Stars */
    .stars { display: flex; gap: 2px; }
    .star { color: var(--gold); font-size: 14px; }
    .star-empty { color: var(--sand); }

    /* Overlay */
    .overlay {
      position: fixed; inset: 0; background: rgba(44,24,16,0.6);
      backdrop-filter: blur(4px); z-index: 999;
      animation: fadeIn 0.2s ease;
    }

    /* Modal */
    .modal {
      position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%);
      background: #fff; border-radius: var(--radius-xl);
      box-shadow: var(--shadow-lg); z-index: 1000;
      max-height: 90vh; overflow-y: auto;
      animation: fadeUp 0.3s ease;
      width: min(92vw, 560px);
    }

    /* Sidebar */
    .sidebar {
      position: fixed; left: 0; top: 0; bottom: 0;
      width: min(320px, 85vw); background: #fff;
      box-shadow: var(--shadow-lg); z-index: 999;
      animation: slideIn 0.3s ease;
      overflow-y: auto;
    }

    /* Risk badge */
    .risk-low { background: #E3F9EE; color: var(--risk-low); }
    .risk-mid { background: #FFF4DE; color: var(--risk-mid); }
    .risk-high { background: #FFE8E5; color: var(--risk-high); }

    /* Offline bar */
    .offline-bar {
      position: fixed; bottom: 0; left: 0; right: 0;
      background: var(--brown-dark); color: var(--gold-light);
      padding: 10px 24px; text-align: center; z-index: 9999;
      font-size: 13px; display: flex; align-items: center;
      justify-content: center; gap: 8px;
    }

    /* Responsive helpers */
    @media(max-width:768px){
      .hide-mobile{display:none!important;}
      .full-mobile{width:100%!important;}
    }
    @media(min-width:769px){
      .hide-desktop{display:none!important;}
    }

    /* Scrollable horizontal */
    .scroll-x { overflow-x: auto; }
    .scroll-x::-webkit-scrollbar { height: 4px; }
    .scroll-x::-webkit-scrollbar-thumb { background: var(--sand); border-radius: 2px; }
  `}</style>
);

// ─── DATA LAYER ───────────────────────────────────────────────────────────────
const DESTINATIONS = [
  {
    id: 1, name: "Rajasthan", state: "Rajasthan",
    img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&q=80&auto=format&fit=crop",
    tagline: "Land of Kings & Forts", risk: 18, type: "heritage",
    about: "Rajasthan, the 'Land of Kings', is India's largest state and a kaleidoscope of majestic forts, ornate palaces, golden deserts, and vibrant culture. From the Pink City of Jaipur to the Blue City of Jodhpur and the golden dunes of Jaisalmer, every corner tells a royal story.",
    places: [
      { name: "Amber Fort, Jaipur", img: "https://images.unsplash.com/photo-1477587458883-47145ed68d1b?w=600&q=80&auto=format&fit=crop", desc: "A stunning hilltop fort with intricate mirror work and elephant rides." },
      { name: "Mehrangarh Fort, Jodhpur", img: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&q=80&auto=format&fit=crop", desc: "One of India's largest forts, overlooking the Blue City below." },
      { name: "Jaisalmer Fort", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80&auto=format&fit=crop", desc: "A living fort rising from the Thar Desert, glowing golden at sunset." },
      { name: "Hawa Mahal, Jaipur", img: "https://images.unsplash.com/photo-1548013146-72479768bada?w=600&q=80&auto=format&fit=crop", desc: "The iconic Palace of Winds with 953 intricate latticed windows." },
      { name: "Sam Sand Dunes", img: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&q=80&auto=format&fit=crop", desc: "Experience camel safaris and cultural evenings under starlit skies." },
      { name: "Lake Pichola, Udaipur", img: "https://images.unsplash.com/photo-1602301932083-94f01a3ec0b1?w=600&q=80&auto=format&fit=crop", desc: "Serene lake with the iconic Lake Palace floating at its centre." },
      { name: "City Palace, Jaipur", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80&auto=format&fit=crop", desc: "A grand palace complex blending Rajput, Mughal and European architecture." },
      { name: "Ranthambore National Park", img: "https://images.unsplash.com/photo-1561731216-c3a4d99437d5?w=600&q=80&auto=format&fit=crop", desc: "India's best tiger reserve with dramatic fort ruins inside the jungle." },
    ]
  },
  {
    id: 2, name: "Kerala Backwaters", state: "Kerala",
    img: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800&q=80&auto=format&fit=crop",
    tagline: "God's Own Country", risk: 8, type: "nature",
    about: "Kerala is a lush tropical paradise of emerald backwaters, misty hill stations, spice-scented forests, and pristine beaches. Drift through serene canals on a traditional houseboat, sip fresh coconut water, and rejuvenate with ancient Ayurvedic therapies.",
    places: [
      { name: "Alleppey Backwaters", img: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&q=80&auto=format&fit=crop", desc: "The Venice of the East – cruise on a rice-boat through peaceful canals." },
      { name: "Munnar Tea Gardens", img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&q=80&auto=format&fit=crop", desc: "Rolling hills blanketed in emerald tea plantations at 1,600m altitude." },
      { name: "Fort Kochi", img: "https://images.unsplash.com/photo-1583249598754-b7a2f59651fb?w=600&q=80&auto=format&fit=crop", desc: "Historic port town with Chinese fishing nets, Jewish synagogues, and spice markets." },
      { name: "Periyar Wildlife Sanctuary", img: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=600&q=80&auto=format&fit=crop", desc: "Boat safaris on Periyar Lake surrounded by elephants and wild boar." },
      { name: "Varkala Beach", img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80&auto=format&fit=crop", desc: "Dramatic red cliffs meeting the Arabian Sea with natural mineral springs." },
      { name: "Athirappilly Waterfalls", img: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80&auto=format&fit=crop", desc: "The 'Niagara of India' – a majestic 80-foot waterfall in dense jungle." },
      { name: "Kovalam Beach", img: "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=600&q=80&auto=format&fit=crop", desc: "Crescent-shaped beach paradise with calm surf and lighthouse views." },
      { name: "Wayanad Hills", img: "https://images.unsplash.com/photo-1583249598754-b7a2f59651fb?w=600&q=80&auto=format&fit=crop", desc: "Misty highlands with tribal villages, bamboo forests, and hidden waterfalls." },
    ]
  },
  {
    id: 3, name: "Ladakh", state: "Jammu & Kashmir",
    img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80&auto=format&fit=crop",
    tagline: "High Altitude Desert", risk: 42, type: "adventure",
    about: "Ladakh is the 'Land of High Passes' — a surreal moonscape of stark mountains, sapphire lakes, ancient monasteries, and fluttering prayer flags. At altitudes above 3,500m, it offers some of the world's most dramatic landscapes and a unique blend of Tibetan Buddhist culture.",
    places: [
      { name: "Pangong Tso Lake", img: "https://images.unsplash.com/photo-1596436889106-be35e843f974?w=600&q=80&auto=format&fit=crop", desc: "The iconic blue lake straddling India and China at 4,350m altitude." },
      { name: "Nubra Valley", img: "https://images.unsplash.com/photo-1622234087043-d06bc5ee13e9?w=600&q=80&auto=format&fit=crop", desc: "A cold desert valley with double-humped Bactrian camels and sand dunes." },
      { name: "Thiksey Monastery", img: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&q=80&auto=format&fit=crop", desc: "A 12-storey monastery complex resembling the Potala Palace of Lhasa." },
      { name: "Khardung La Pass", img: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&q=80&auto=format&fit=crop", desc: "One of the world's highest motorable roads at 5,359m above sea level." },
      { name: "Leh Palace", img: "https://images.unsplash.com/photo-1548013146-72479768bada?w=600&q=80&auto=format&fit=crop", desc: "A 17th-century nine-storey palace overlooking Leh town and Stok Kangri." },
      { name: "Magnetic Hill", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80&auto=format&fit=crop", desc: "A gravity-defying hill where vehicles appear to roll uphill on their own." },
      { name: "Tso Moriri Lake", img: "https://images.unsplash.com/photo-1605715579963-70f08b4e2e6e?w=600&q=80&auto=format&fit=crop", desc: "Remote high-altitude lake in the Changthang plateau, home to rare birds." },
      { name: "Zanskar Valley", img: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80&auto=format&fit=crop", desc: "A remote frozen river trekking route (Chadar Trek) through ice gorges." },
    ]
  },
  {
    id: 4, name: "Goa", state: "Goa",
    img: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800&q=80&auto=format&fit=crop",
    tagline: "Sun, Sand & Spice", risk: 12, type: "beach",
    about: "Goa, India's smallest state, is a sun-drenched paradise where Portuguese colonial history meets tropical beaches, vibrant nightlife, and incredible seafood. From the party beaches of Calangute to the serene shores of Palolem, Goa has a personality for every traveler.",
    places: [
      { name: "Baga Beach", img: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&q=80&auto=format&fit=crop", desc: "North Goa's most vibrant beach with water sports, shacks, and nightlife." },
      { name: "Basilica of Bom Jesus", img: "https://images.unsplash.com/photo-1605715579963-70f08b4e2e6e?w=600&q=80&auto=format&fit=crop", desc: "A UNESCO World Heritage Baroque church housing St. Francis Xavier's tomb." },
      { name: "Palolem Beach", img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80&auto=format&fit=crop", desc: "A crescent-shaped paradise in South Goa with crystal-clear waters." },
      { name: "Dudhsagar Waterfalls", img: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80&auto=format&fit=crop", desc: "A majestic 4-tiered waterfall on the Mandovi River in dense jungle." },
      { name: "Fort Aguada", img: "https://images.unsplash.com/photo-1477587458883-47145ed68d1b?w=600&q=80&auto=format&fit=crop", desc: "A 17th-century Portuguese fort overlooking the Arabian Sea." },
      { name: "Anjuna Flea Market", img: "https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=600&q=80&auto=format&fit=crop", desc: "A legendary Wednesday market with handicrafts, spices, and bohemian culture." },
      { name: "Calangute Beach", img: "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=600&q=80&auto=format&fit=crop", desc: "The 'Queen of Beaches' — North Goa's longest and most popular stretch." },
      { name: "Spice Plantation, Ponda", img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&q=80&auto=format&fit=crop", desc: "Guided tours through aromatic plantations of cardamom, pepper, and vanilla." },
    ]
  },
  {
    id: 5, name: "Varanasi", state: "Uttar Pradesh",
    img: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=800&q=80&auto=format&fit=crop",
    tagline: "Spiritual Capital of India", risk: 22, type: "spiritual",
    about: "Varanasi, one of the world's oldest living cities, is the spiritual heartbeat of India. On the banks of the sacred Ganges, thousands gather daily for prayers, rituals, and the mesmerizing Ganga Aarti ceremony. This city of moksha (liberation) is unlike anywhere else on earth.",
    places: [
      { name: "Dashashwamedh Ghat", img: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=600&q=80&auto=format&fit=crop", desc: "The main ghat famous for the spectacular nightly Ganga Aarti ceremony." },
      { name: "Kashi Vishwanath Temple", img: "https://images.unsplash.com/photo-1477587458883-47145ed68d1b?w=600&q=80&auto=format&fit=crop", desc: "One of the 12 sacred Jyotirlinga temples dedicated to Lord Shiva." },
      { name: "Manikarnika Ghat", img: "https://images.unsplash.com/photo-1548013146-72479768bada?w=600&q=80&auto=format&fit=crop", desc: "The sacred cremation ghat that burns 24/7 – a profound meditation on life." },
      { name: "Sarnath", img: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&q=80&auto=format&fit=crop", desc: "Where Buddha gave his first sermon — home to the Dhamek Stupa (500 AD)." },
      { name: "Ramnagar Fort", img: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&q=80&auto=format&fit=crop", desc: "An 18th-century fort on the opposite bank of the Ganges with a museum." },
      { name: "Morning Boat Ride", img: "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=600&q=80&auto=format&fit=crop", desc: "Witness the sunrise over the Ganges from a wooden boat at dawn." },
      { name: "Assi Ghat", img: "https://images.unsplash.com/photo-1602301932083-94f01a3ec0b1?w=600&q=80&auto=format&fit=crop", desc: "A peaceful ghat popular with pilgrims, yoga seekers, and sunset viewers." },
      { name: "Bharat Mata Temple", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80&auto=format&fit=crop", desc: "A unique temple housing a large marble relief map of undivided India." },
    ]
  },
  {
    id: 6, name: "Coorg", state: "Karnataka",
    img: "https://images.unsplash.com/photo-1583249598754-b7a2f59651fb?w=800&q=80&auto=format&fit=crop",
    tagline: "Scotland of India", risk: 10, type: "nature",
    about: "Coorg (Kodagu) is Karnataka's crown jewel — a misty hill station draped in coffee and cardamom plantations, dense forests, and gushing waterfalls. Known as the 'Scotland of India' for its rolling green hills and cool climate, it's a haven for nature lovers and trekkers.",
    places: [
      { name: "Abbey Falls", img: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80&auto=format&fit=crop", desc: "A picturesque 70-foot waterfall surrounded by coffee and spice plantations." },
      { name: "Raja's Seat", img: "https://images.unsplash.com/photo-1583249598754-b7a2f59651fb?w=600&q=80&auto=format&fit=crop", desc: "A garden viewpoint where Coorg kings once watched the glorious sunset." },
      { name: "Nagarhole National Park", img: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=600&q=80&auto=format&fit=crop", desc: "Lush forest reserve with tigers, leopards, elephants, and gaur herds." },
      { name: "Dubare Elephant Camp", img: "https://images.unsplash.com/photo-1622234087043-d06bc5ee13e9?w=600&q=80&auto=format&fit=crop", desc: "An interactive elephant camp on the banks of the River Cauvery." },
      { name: "Madikeri Fort", img: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&q=80&auto=format&fit=crop", desc: "A 17th-century fort with a small museum, chapel, and panoramic views." },
      { name: "Coffee Plantation Tour", img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&q=80&auto=format&fit=crop", desc: "Walk through fragrant estates learning how Coorg's famous coffee is grown." },
      { name: "Talakaveri", img: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80&auto=format&fit=crop", desc: "The sacred origin of the River Cauvery, set amidst forests at 1,276m." },
      { name: "Brahmagiri Trek", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80&auto=format&fit=crop", desc: "A rewarding trek through Coorg's pristine forests to ancient temples." },
    ]
  },
  {
    id: 7, name: "Andaman Islands", state: "Andaman & Nicobar",
    img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80&auto=format&fit=crop",
    tagline: "Emerald Islands", risk: 15, type: "beach",
    about: "The Andaman Islands are a remote paradise of over 570 islands in the Bay of Bengal, boasting some of Asia's most pristine beaches, vibrant coral reefs, and rich colonial history at the infamous Cellular Jail. It's India's best-kept secret for underwater adventures.",
    places: [
      { name: "Radhanagar Beach, Havelock", img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80&auto=format&fit=crop", desc: "Rated one of Asia's best beaches — powdery white sand and turquoise waters." },
      { name: "Cellular Jail, Port Blair", img: "https://images.unsplash.com/photo-1477587458883-47145ed68d1b?w=600&q=80&auto=format&fit=crop", desc: "The infamous 'Kala Pani' colonial prison – now a national memorial museum." },
      { name: "Elephant Beach Snorkelling", img: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=600&q=80&auto=format&fit=crop", desc: "Crystal-clear waters with vibrant coral reefs and tropical fish." },
      { name: "Neil Island Beaches", img: "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=600&q=80&auto=format&fit=crop", desc: "Laid-back island paradise with natural bridges and pristine coral beaches." },
      { name: "Scuba Diving, North Bay", img: "https://images.unsplash.com/photo-1596436889106-be35e843f974?w=600&q=80&auto=format&fit=crop", desc: "World-class dive sites with visibility up to 30m and diverse marine life." },
      { name: "Baratang Island Caves", img: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&q=80&auto=format&fit=crop", desc: "Mangrove jungle cruise leading to spectacular limestone stalactite caves." },
      { name: "Ross Island", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80&auto=format&fit=crop", desc: "Ruins of the former British administrative capital — eerily beautiful." },
      { name: "Jolly Buoy Island", img: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&q=80&auto=format&fit=crop", desc: "A pristine coral island with glass-bottom boats and sea-walking." },
    ]
  },
  {
    id: 8, name: "Himachal Pradesh", state: "Himachal Pradesh",
    img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80&auto=format&fit=crop",
    tagline: "Mountains & Valleys", risk: 28, type: "adventure",
    about: "Himachal Pradesh is a Himalayan wonderland of snow-capped peaks, verdant valleys, gushing rivers, and charming hill towns. From the colonial charm of Shimla to the hippie haven of Kasol, the apple orchards of Manali to the mystical monasteries of Spiti — HP has it all.",
    places: [
      { name: "Rohtang Pass", img: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80&auto=format&fit=crop", desc: "A dramatic high mountain pass at 3,978m with snow even in summer." },
      { name: "Solang Valley, Manali", img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=600&q=80&auto=format&fit=crop", desc: "Adventure hub for skiing, paragliding, and snowboarding in the Himalayas." },
      { name: "Shimla Ridge & Mall Road", img: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&q=80&auto=format&fit=crop", desc: "The charming colonial heart of Shimla with Victorian architecture." },
      { name: "Spiti Valley", img: "https://images.unsplash.com/photo-1606298855672-3efb63017be8?w=600&q=80&auto=format&fit=crop", desc: "A remote high-altitude desert valley with ancient monasteries and snow peaks." },
      { name: "Triund Trek, Dharamshala", img: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80&auto=format&fit=crop", desc: "A popular trek with stunning views of the Dhauladhar mountain range." },
      { name: "Kasol & Parvati Valley", img: "https://images.unsplash.com/photo-1605715579963-70f08b4e2e6e?w=600&q=80&auto=format&fit=crop", desc: "A scenic valley along the Parvati River popular for treks and cafe culture." },
      { name: "Key Monastery, Spiti", img: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&q=80&auto=format&fit=crop", desc: "A 1,000-year-old Tibetan Buddhist monastery perched dramatically at 4,166m." },
      { name: "Great Himalayan National Park", img: "https://images.unsplash.com/photo-1561731216-c3a4d99437d5?w=600&q=80&auto=format&fit=crop", desc: "A UNESCO World Heritage Site with 375+ fauna species and pristine forests." },
    ]
  },
  {
    id: 9, name: "Agra", state: "Uttar Pradesh",
    img: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800&q=80&auto=format&fit=crop",
    tagline: "City of the Taj Mahal", risk: 20, type: "heritage",
    about: "Agra, on the banks of the Yamuna River, is home to the world's greatest monument to love — the Taj Mahal. But beyond the Taj, Agra has the magnificent Agra Fort, the ghost city of Fatehpur Sikri, and the artisan tradition of marble inlay work that has survived for 400 years.",
    places: [
      { name: "Taj Mahal", img: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=600&q=80&auto=format&fit=crop", desc: "The undisputed wonder of the world — an ivory-white marble mausoleum at dawn." },
      { name: "Agra Fort", img: "https://images.unsplash.com/photo-1477587458883-47145ed68d1b?w=600&q=80&auto=format&fit=crop", desc: "A massive UNESCO-listed fort where Shah Jahan spent his final years." },
      { name: "Fatehpur Sikri", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80&auto=format&fit=crop", desc: "A ghost Mughal city abandoned after 15 years — perfectly preserved in red sandstone." },
      { name: "Mehtab Bagh", img: "https://images.unsplash.com/photo-1548013146-72479768bada?w=600&q=80&auto=format&fit=crop", desc: "A moonlit garden across the Yamuna offering the most serene Taj Mahal views." },
      { name: "Itmad-ud-Daulah", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80&auto=format&fit=crop", desc: "The 'Baby Taj' — a delicate jewel-like tomb predating the Taj Mahal." },
      { name: "Jama Masjid, Agra", img: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&q=80&auto=format&fit=crop", desc: "One of India's largest mosques, built by Shah Jahan in 1648." },
      { name: "Kinari Bazaar", img: "https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=600&q=80&auto=format&fit=crop", desc: "A bustling traditional market near Agra Fort selling marble crafts and sweets." },
      { name: "Taj at Sunrise", img: "https://images.unsplash.com/photo-1596436889106-be35e843f974?w=600&q=80&auto=format&fit=crop", desc: "The most magical way to see the Taj Mahal — glowing pink-orange at first light." },
    ]
  },
  {
    id: 10, name: "Darjeeling", state: "West Bengal",
    img: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&q=80&auto=format&fit=crop",
    tagline: "Queen of the Hills", risk: 12, type: "nature",
    about: "Darjeeling, the 'Queen of the Hills', enchants visitors with its world-famous tea gardens, breathtaking views of Kanchenjunga, the joyful toy train, and a cool mountain climate that refreshes the soul. It's a perfect blend of colonial nostalgia and Himalayan grandeur.",
    places: [
      { name: "Tiger Hill Sunrise", img: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80&auto=format&fit=crop", desc: "Watch the first rays of sun paint Kanchenjunga golden from 2,590m altitude." },
      { name: "Darjeeling Toy Train", img: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&q=80&auto=format&fit=crop", desc: "UNESCO-listed narrow-gauge railway looping through tea gardens and mountains." },
      { name: "Happy Valley Tea Estate", img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&q=80&auto=format&fit=crop", desc: "Walk through the oldest tea estate in Darjeeling and taste fresh first flush." },
      { name: "Batasia Loop", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80&auto=format&fit=crop", desc: "A spiral railway loop with a war memorial and Himalayan panoramas." },
      { name: "Ghoom Monastery", img: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&q=80&auto=format&fit=crop", desc: "One of the most important Tibetan Buddhist monasteries in the Himalayan region." },
      { name: "Singalila Ridge Trek", img: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80&auto=format&fit=crop", desc: "Multi-day trek through rhododendron forests to Sandakphu (3,636m)." },
      { name: "Rock Garden", img: "https://images.unsplash.com/photo-1583249598754-b7a2f59651fb?w=600&q=80&auto=format&fit=crop", desc: "Stepped terraced garden with a cascading stream and colourful flora." },
      { name: "Chowrasta Mall", img: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&q=80&auto=format&fit=crop", desc: "The charming pedestrian promenade at the heart of colonial Darjeeling." },
    ]
  },
  {
    id: 11, name: "Mysore", state: "Karnataka",
    img: "https://images.unsplash.com/photo-1600100397608-4a3d1d3c4ab6?w=800&q=80&auto=format&fit=crop",
    tagline: "City of Palaces", risk: 8, type: "heritage",
    about: "Mysore, the 'City of Palaces', is Karnataka's most regal city — famous for its luminous Mysore Palace, vibrant Dasara festival, fragrant sandalwood products, and the sacred Chamundi Hill. It is one of India's most visited and beloved heritage cities.",
    places: [
      { name: "Mysore Palace", img: "https://images.unsplash.com/photo-1600100397608-4a3d1d3c4ab6?w=600&q=80&auto=format&fit=crop", desc: "A breathtaking Indo-Saracenic palace illuminated by 100,000 bulbs on weekends." },
      { name: "Chamundi Hill", img: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=600&q=80&auto=format&fit=crop", desc: "Sacred hill with the 1,000-step climb to Sri Chamundeshwari Temple." },
      { name: "Brindavan Gardens", img: "https://images.unsplash.com/photo-1583249598754-b7a2f59651fb?w=600&q=80&auto=format&fit=crop", desc: "Famous terraced garden with musical fountains illuminated in the evenings." },
      { name: "St. Philomena's Church", img: "https://images.unsplash.com/photo-1605715579963-70f08b4e2e6e?w=600&q=80&auto=format&fit=crop", desc: "A magnificent neo-Gothic cathedral built in 1936 with stained glass windows." },
      { name: "Devaraja Market", img: "https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=600&q=80&auto=format&fit=crop", desc: "A 100-year-old market bursting with flowers, spices, silks, and incense." },
      { name: "Ranganthittu Bird Sanctuary", img: "https://images.unsplash.com/photo-1561731216-c3a4d99437d5?w=600&q=80&auto=format&fit=crop", desc: "A river island sanctuary hosting thousands of migratory birds and crocodiles." },
      { name: "Nagarhole Safari", img: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=600&q=80&auto=format&fit=crop", desc: "A nearby wildlife reserve with tigers, leopards, and elephant herds." },
      { name: "Mysore Dasara Festival", img: "https://images.unsplash.com/photo-1548013146-72479768bada?w=600&q=80&auto=format&fit=crop", desc: "The Royal Dasara — India's grandest festival with a golden elephant procession." },
    ]
  },
  {
    id: 12, name: "Rishikesh & Haridwar", state: "Uttarakhand",
    img: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=800&q=80&auto=format&fit=crop",
    tagline: "Yoga Capital of the World", risk: 18, type: "spiritual",
    about: "Rishikesh and Haridwar together form the spiritual gateway to the Himalayas. Rishikesh is the world's yoga and adventure capital, set where the Ganges emerges from the mountains. Haridwar hosts the famous Kumbh Mela — the world's largest human gathering.",
    places: [
      { name: "Laxman Jhula", img: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=600&q=80&auto=format&fit=crop", desc: "The iconic iron suspension bridge over the Ganges, lined with temples." },
      { name: "Har Ki Pauri, Haridwar", img: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=600&q=80&auto=format&fit=crop", desc: "The sacred ghat where the Ganga Aarti lights up the Ganges at dusk." },
      { name: "River Rafting, Rishikesh", img: "https://images.unsplash.com/photo-1622234087043-d06bc5ee13e9?w=600&q=80&auto=format&fit=crop", desc: "Grade 3-4 white water rafting on the Ganges through thrilling rapids." },
      { name: "Triveni Ghat", img: "https://images.unsplash.com/photo-1602301932083-94f01a3ec0b1?w=600&q=80&auto=format&fit=crop", desc: "Where three sacred rivers meet — the site of powerful evening aartis." },
      { name: "Neer Garh Waterfall", img: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80&auto=format&fit=crop", desc: "A scenic 2-km forest trek to a beautiful multi-tiered waterfall." },
      { name: "Yoga Ashrams", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80&auto=format&fit=crop", desc: "World-famous ashrams like Parmarth Niketan offering yoga and meditation." },
      { name: "Bungee Jumping", img: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80&auto=format&fit=crop", desc: "India's highest bungee jump at 83m — pure adrenaline over the Ganges." },
      { name: "Rajaji National Park", img: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=600&q=80&auto=format&fit=crop", desc: "Elephant and tiger territory at the foothills of the Shivalik Himalayas." },
    ]
  },
];

const AGENCIES = [
  { id: 1, name: "Royal Rajasthan Tours", dest: [1], rating: 4.8, reviews: 312, price: 12500, type: "luxury", desc: "Premium heritage tours across Rajasthan's royal palaces and sand dunes.", verified: true, img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=400&q=80&auto=format&fit=crop" },
  { id: 2, name: "Kerala Bliss Travels", dest: [2], rating: 4.7, reviews: 278, price: 9800, type: "nature", desc: "Authentic backwater houseboat and Ayurveda retreat experiences.", verified: true, img: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=400&q=80&auto=format&fit=crop" },
  { id: 3, name: "High Altitude Expeditions", dest: [3,8], rating: 4.9, reviews: 189, price: 22000, type: "adventure", desc: "Expert-led Ladakh treks, Spiti Valley circuits, and winter expeditions.", verified: true, img: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&q=80&auto=format&fit=crop" },
  { id: 4, name: "Goa Vibes", dest: [4], rating: 4.5, reviews: 445, price: 7500, type: "budget", desc: "Beach shacks, water sports packages, and North-South Goa circuit tours.", verified: false, img: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400&q=80&auto=format&fit=crop" },
  { id: 5, name: "Moksha Yatra", dest: [5,12], rating: 4.6, reviews: 221, price: 8200, type: "spiritual", desc: "Sacred pilgrimages: Varanasi ghats, Bodh Gaya, Allahabad Triveni.", verified: true, img: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=400&q=80&auto=format&fit=crop" },
  { id: 6, name: "Wanderlust India", dest: [1,4,6,7,9,11], rating: 4.4, reviews: 567, price: 6900, type: "budget", desc: "Budget-friendly multi-destination packages across India's top spots.", verified: true, img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80&auto=format&fit=crop" },
  { id: 7, name: "Taj & Heritage Trails", dest: [9,1,11], rating: 4.7, reviews: 334, price: 11500, type: "heritage", desc: "Expert-guided heritage circuits covering the Golden Triangle and beyond.", verified: true, img: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=400&q=80&auto=format&fit=crop" },
  { id: 8, name: "Himalayan Soul Journeys", dest: [8,3,10,12], rating: 4.8, reviews: 156, price: 18000, type: "adventure", desc: "Transformative Himalayan journeys — treks, yoga retreats and spiritual trails.", verified: true, img: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&q=80&auto=format&fit=crop" },
];

const PACKAGES = [
  { id: 1, agencyId: 1, destId: 1, title: "Royal Rajasthan Heritage Circuit", price: 28500, duration: "7 Days / 6 Nights", type: "luxury", img: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&q=80&auto=format&fit=crop", inclusions: ["Luxury hotel stay", "All meals", "Private AC vehicle", "Professional guide", "Monument entries"], exclusions: ["Flights", "Personal expenses", "Travel insurance"], itinerary: ["Day 1: Arrive Jaipur – City Palace, Jantar Mantar", "Day 2: Amber Fort, Nahargarh Fort, Sunset at Jal Mahal", "Day 3: Drive to Jodhpur – Mehrangarh Fort", "Day 4: Osian Desert, Camel Safari, Sunset point", "Day 5: Drive to Jaisalmer – Golden Fort walk", "Day 6: Sam Sand Dunes, Cultural Evening, Bonfire", "Day 7: Depart from Jodhpur"] },
  { id: 2, agencyId: 2, destId: 2, title: "Kerala Backwater Serenity", price: 18900, duration: "5 Days / 4 Nights", type: "nature", img: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800&q=80&auto=format&fit=crop", inclusions: ["Houseboat stay (2 nights)", "Ayurveda sessions", "Spice plantation tour", "All meals"], exclusions: ["Flights", "Personal shopping"], itinerary: ["Day 1: Arrive Kochi – Fort Kochi walk, Chinese fishing nets", "Day 2: Drive to Alleppey – Board houseboat at noon", "Day 3: Backwaters cruise to Kollam, village stops", "Day 4: Ayurveda resort Munnar, tea garden visit", "Day 5: Tea plantations, Eravikulam NP, Depart"] },
  { id: 3, agencyId: 3, destId: 3, title: "Ladakh Royal Expedition", price: 45000, duration: "10 Days / 9 Nights", type: "adventure", img: "https://images.unsplash.com/photo-1596436889106-be35e843f974?w=800&q=80&auto=format&fit=crop", inclusions: ["Permits (ILP/PAP)", "Camping gear", "Professional mountaineer", "Oxygen cylinder", "All meals"], exclusions: ["Flights to Leh", "Travel insurance (mandatory)"], itinerary: ["Day 1-2: Leh acclimatization, local market", "Day 3: Shanti Stupa, Leh Palace, Namgyal Tsemo", "Day 4: Khardung La Pass (5,359m), Nubra Valley", "Day 5: Bactrian camel safari, Diskit Monastery", "Day 6: Drive to Pangong Tso Lake (4,350m)", "Day 7: Sunrise at Pangong, drive to Tso Moriri", "Day 8: Tso Moriri, Changtang Wildlife Sanctuary", "Day 9: Manali Highway – More Plains, Sarchu", "Day 10: Depart Manali"] },
  { id: 4, agencyId: 4, destId: 4, title: "Goa Fun & Beach Package", price: 12500, duration: "4 Days / 3 Nights", type: "budget", img: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800&q=80&auto=format&fit=crop", inclusions: ["Hotel stay", "Breakfast", "North Goa sightseeing tour", "Water sports (basic)"], exclusions: ["Lunch/Dinner", "Flights", "Premium water sports"], itinerary: ["Day 1: Arrive, Baga Beach sunset, beachside dinner", "Day 2: North Goa – Calangute, Anjuna, Vagator beaches", "Day 3: Old Goa churches (UNESCO), Spice farm, Dudhsagar", "Day 4: South Goa – Palolem, Colva, Depart"] },
  { id: 5, agencyId: 7, destId: 9, title: "Taj Mahal & Golden Triangle", price: 22000, duration: "6 Days / 5 Nights", type: "heritage", img: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800&q=80&auto=format&fit=crop", inclusions: ["4-star hotels", "All breakfasts", "AC vehicle", "Entry tickets", "English guide"], exclusions: ["Flights", "Lunch/Dinner", "Personal shopping"], itinerary: ["Day 1: Arrive Delhi – Red Fort, Qutub Minar, India Gate", "Day 2: Delhi – Humayun's Tomb, Chandni Chowk", "Day 3: Drive to Agra – Agra Fort, Taj sunset view", "Day 4: Taj Mahal sunrise, Fatehpur Sikri", "Day 5: Drive to Jaipur – Amber Fort, City Palace", "Day 6: Jaipur – Hawa Mahal, Jantar Mantar, Depart"] },
  { id: 6, agencyId: 8, destId: 8, title: "Himachal Himalayan Escape", price: 31000, duration: "8 Days / 7 Nights", type: "adventure", img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80&auto=format&fit=crop", inclusions: ["Boutique hotel stays", "All meals", "Jeep transfers", "Trekking guide", "Camping equipment"], exclusions: ["Flights to Manali", "Travel insurance", "Personal expenses"], itinerary: ["Day 1: Arrive Manali – Old Manali, Hadimba Temple", "Day 2: Solang Valley – Zorbing, Paragliding", "Day 3: Rohtang Pass (if open), snow activities", "Day 4: Drive to Kasol – Parvati Valley walk", "Day 5: Kheerganga Trek (12km round trip)", "Day 6: Drive to Shimla – Naldehra golf course", "Day 7: Shimla – Mall Road, Christ Church, Jakhu Temple", "Day 8: Kufri, toy train, Depart Shimla"] },
  { id: 7, agencyId: 5, destId: 5, title: "Spiritual Varanasi & Bodh Gaya", price: 15500, duration: "5 Days / 4 Nights", type: "spiritual", img: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=800&q=80&auto=format&fit=crop", inclusions: ["Heritage guesthouse on the Ghats", "All meals (pure veg)", "Morning boat ride", "Ganga Aarti ceremony", "Yoga session"], exclusions: ["Flights", "Personal donations at temples"], itinerary: ["Day 1: Arrive Varanasi – Evening Ganga Aarti at Dashashwamedh", "Day 2: Sunrise boat ride, Kashi Vishwanath Temple", "Day 3: Sarnath – Dhamek Stupa, Deer Park, Buddhist Museum", "Day 4: Drive to Bodh Gaya – Mahabodhi Temple (UNESCO)", "Day 5: Bodh Gaya meditation, Depart"] },
  { id: 8, agencyId: 6, destId: 7, title: "Andaman Island Hopper", price: 38000, duration: "7 Days / 6 Nights", type: "beach", img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80&auto=format&fit=crop", inclusions: ["Resort stays", "All meals", "Speed boat transfers", "Scuba diving (2 dives)", "Snorkelling gear"], exclusions: ["Flights to Port Blair", "Travel insurance", "Optional water sports"], itinerary: ["Day 1: Arrive Port Blair – Cellular Jail Light & Sound Show", "Day 2: Cruise to Havelock Island – Radhanagar Beach", "Day 3: Elephant Beach snorkelling, Scuba diving", "Day 4: Neil Island – Laxmanpur & Bharatpur beaches", "Day 5: Baratang – Limestone caves, mangrove tour", "Day 6: North Bay Island – Sea walking, glass boat", "Day 7: Ross Island ruins, Depart Port Blair"] },
];

const REVIEWS = [
  { id: 1, agencyId: 1, user: "Priya Sharma", avatar: "PS", rating: 5, comment: "Absolutely magical experience! The heritage hotels were stunning and the guide was extremely knowledgeable. Worth every rupee.", date: "Feb 2025" },
  { id: 2, agencyId: 1, user: "Rahul Mehta", avatar: "RM", rating: 4, comment: "Great organization and seamless logistics. Jodhpur was the highlight. Would book again for South India circuit.", date: "Jan 2025" },
  { id: 3, agencyId: 2, user: "Ananya Iyer", avatar: "AI", rating: 5, comment: "The houseboat experience was other-worldly. Pristine waters, amazing fish curry, and the sunsets... unforgettable!", date: "Mar 2025" },
  { id: 4, agencyId: 3, user: "Vikram Singh", avatar: "VS", rating: 5, comment: "High Altitude Expeditions are true professionals. Their safety protocols at Khardung La saved us from AMS.", date: "Aug 2024" },
];

const CHAT_MESSAGES_DEFAULT = [
  { id: 1, from: "agency", text: "Namaste! 🙏 Welcome to TravelHub. How can I help you plan your dream trip today?", time: "10:00 AM" },
];

// Mock India map coordinates for destinations
const DEST_COORDS = {
  1:  { lat: 26.9124, lng: 75.7873, label: "Jaipur, Rajasthan" },
  2:  { lat: 9.4981,  lng: 76.3388, label: "Alleppey, Kerala" },
  3:  { lat: 34.1526, lng: 77.5771, label: "Leh, Ladakh" },
  4:  { lat: 15.2993, lng: 74.1240, label: "Panaji, Goa" },
  5:  { lat: 25.3176, lng: 82.9739, label: "Varanasi, UP" },
  6:  { lat: 12.3375, lng: 75.8069, label: "Madikeri, Coorg" },
  7:  { lat: 11.7401, lng: 92.6586, label: "Port Blair, Andaman" },
  8:  { lat: 31.1048, lng: 77.1734, label: "Shimla, HP" },
  9:  { lat: 27.1767, lng: 78.0081, label: "Agra, UP" },
  10: { lat: 27.0410, lng: 88.2663, label: "Darjeeling, WB" },
  11: { lat: 12.2958, lng: 76.6394, label: "Mysore, Karnataka" },
  12: { lat: 30.0869, lng: 78.2676, label: "Rishikesh, Uttarakhand" },
};

// ─── CONTEXT ──────────────────────────────────────────────────────────────────
const AppContext = createContext(null);

function AppProvider({ children }) {
  const [page, setPage] = useState("home");
  const [pageParams, setPageParams] = useState({});
  const [user, setUser] = useState(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [backendOnline, setBackendOnline] = useState(null); // null=checking, true, false
  const [cachedSearches, setCachedSearches] = useState(() => {
    try { return JSON.parse(localStorage.getItem("th_cache") || "[]"); } catch { return []; }
  });
  const [bookings, setBookings] = useState([]);
  const [notifications, setNotifications] = useState([]);
  // Live backend data
  const [destinations, setDestinations] = useState(DESTINATIONS);
  const [agencies, setAgencies] = useState(AGENCIES);
  const [packages, setPackages] = useState(PACKAGES);

  // Check backend connectivity + load data
  useEffect(() => {
    async function loadData() {
      try {
        const [dests, agns, pkgs] = await Promise.all([
          destinationsAPI.getAll(),
          agenciesAPI.getAll(),
          packagesAPI.getAll(),
        ]);
        if (dests?.length) setDestinations(dests);
        if (agns?.length) setAgencies(agns);
        if (pkgs?.length) setPackages(pkgs);
        setBackendOnline(true);
      } catch {
        setBackendOnline(false); // Fall back to mock data silently
      }
    }
    loadData();
  }, []);

  // Restore session from token
  useEffect(() => {
    const token = getToken();
    if (token) {
      authAPI.me().then(u => setUser(u)).catch(() => clearToken());
    }
  }, []);

  useEffect(() => {
    const online = () => setIsOffline(false);
    const offline = () => setIsOffline(true);
    window.addEventListener("online", online);
    window.addEventListener("offline", offline);
    return () => { window.removeEventListener("online", online); window.removeEventListener("offline", offline); };
  }, []);

  const navigate = useCallback((p, params = {}) => {
    setPage(p);
    setPageParams(params);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const cacheSearch = useCallback((query, results) => {
    const entry = { query, results, ts: Date.now() };
    const updated = [entry, ...cachedSearches.filter(c => c.query !== query)].slice(0, 10);
    setCachedSearches(updated);
    try { localStorage.setItem("th_cache", JSON.stringify(updated)); } catch {}
  }, [cachedSearches]);

  const addNotification = useCallback((msg) => {
    const id = Date.now();
    setNotifications(n => [...n, { id, msg }]);
    setTimeout(() => setNotifications(n => n.filter(x => x.id !== id)), 4000);
  }, []);

  const loginUser = useCallback(async (email, password) => {
    const res = await authAPI.login({ email, password });
    setToken(res.access_token);
    setUser(res.user);
    return res.user;
  }, []);

  const registerUser = useCallback(async (data) => {
    const res = await authAPI.register(data);
    setToken(res.access_token);
    setUser(res.user);
    return res.user;
  }, []);

  const logoutUser = useCallback(() => {
    clearToken();
    setUser(null);
  }, []);

  return (
    <AppContext.Provider value={{
      page, navigate, pageParams, user, setUser, loginUser, registerUser, logoutUser,
      isOffline, backendOnline, cachedSearches, cacheSearch,
      bookings, setBookings, notifications, addNotification,
      destinations, agencies, packages, setPackages,
    }}>
      {children}
    </AppContext.Provider>
  );
}


// Safe image component with fallback
function Img({ src, alt="", style={}, onMouseEnter, onMouseLeave, ...props }) {
  const fallbackColors = ["#C4622D","#3D6B20","#4A90A4","#C9963A","#8B5E3C","#2D5016","#5C3317","#7BAE6E"];
  const color = fallbackColors[(alt.charCodeAt(0) || 65) % fallbackColors.length];
  const handleError = (e) => {
    e.target.onerror = null;
    e.target.style.background = color;
    e.target.src = `data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='500'><rect width='800' height='500' fill='${encodeURIComponent(color)}'/><text x='400' y='240' font-family='serif' font-size='28' font-weight='bold' fill='white' text-anchor='middle'>${encodeURIComponent('📍 ' + (alt||'India'))}</text><text x='400' y='280' font-family='sans-serif' font-size='16' fill='rgba(255,255,255,0.7)' text-anchor='middle'>Image loading...</text></svg>`;
  };
  return <img src={src} alt={alt} style={style} onError={handleError} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave} {...props} />;
}

const useApp = () => useContext(AppContext);

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function Stars({ rating, size = 14 }) {
  return (
    <div className="stars">
      {[1,2,3,4,5].map(i => (
        <span key={i} className={i <= Math.round(rating) ? "star" : "star star-empty"} style={{ fontSize: size }}>★</span>
      ))}
    </div>
  );
}

function RiskBadge({ risk }) {
  const level = risk < 20 ? "low" : risk < 40 ? "mid" : "high";
  const label = risk < 20 ? "Low Risk" : risk < 40 ? "Moderate Risk" : "High Risk";
  return (
    <span className={`badge risk-${level}`} style={{ fontWeight: 600 }}>
      {level === "low" ? "🟢" : level === "mid" ? "🟡" : "🔴"} {label} {risk}%
    </span>
  );
}

function Avatar({ initials, size = 38 }) {
  const colors = ["#C4622D", "#2D5016", "#4A90A4", "#C9963A", "#8B5E3C"];
  const color = colors[initials.charCodeAt(0) % colors.length];
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: color, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: size * 0.35, flexShrink: 0, fontFamily: "var(--font-body)" }}>
      {initials}
    </div>
  );
}

function Notification({ msg }) {
  return (
    <div style={{ background: "var(--brown-dark)", color: "#fff", padding: "12px 20px", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-lg)", fontSize: 14, display: "flex", alignItems: "center", gap: 8 }}>
      ✓ {msg}
    </div>
  );
}

function Loader() {
  return (
    <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
      <div style={{ width: 36, height: 36, border: "3px solid var(--sand)", borderTopColor: "var(--forest-mid)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
    </div>
  );
}

// ─── NAV ──────────────────────────────────────────────────────────────────────
function Navbar() {
  const { navigate, user, logoutUser, page, backendOnline } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { label: "Explore", page: "search" },
    { label: "Destinations", page: "destinations" },
    { label: "Agencies", page: "agencies" },
    { label: "✨ AI Search", page: "aisearch" },
    { label: "🧬 DNA Quiz", page: "dna" },
    { label: "🏕️ Trip Room", page: "triproom" },
  ];

  return (
    <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 900, background: "rgba(251,248,243,0.95)", backdropFilter: "blur(12px)", borderBottom: "1px solid var(--sand)", padding: "0 24px", height: 68, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      {/* Logo */}
      <div onClick={() => navigate("home")} style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 36, height: 36, background: "var(--forest-mid)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 18 }}>✈</div>
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 18, color: "var(--brown-dark)", lineHeight: 1 }}>TravelHub</div>
          <div style={{ fontSize: 10, color: "var(--brown-light)", letterSpacing: 2, textTransform: "uppercase", display: "flex", alignItems: "center", gap: 4 }}>
            India
            {backendOnline !== null && (
              <span title={backendOnline ? "Backend connected" : "Using offline data"} style={{ width: 6, height: 6, borderRadius: "50%", background: backendOnline ? "var(--risk-low)" : "var(--risk-mid)", display: "inline-block" }} />
            )}
          </div>
        </div>
      </div>

      {/* Desktop links */}
      <div className="hide-mobile" style={{ display: "flex", gap: 4 }}>
        {navLinks.map(l => (
          <button key={l.label} onClick={() => navigate(l.page)} className="btn btn-ghost" style={{ color: "var(--brown-mid)", background: "transparent", border: "none", fontSize: 15 }}>
            {l.label}
          </button>
        ))}
      </div>

      {/* Auth */}
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        {user ? (
          <>
            <button onClick={() => navigate("dashboard")} className="btn btn-outline btn-sm hide-mobile">
              Dashboard
            </button>
            <Avatar initials={user.name.slice(0,2).toUpperCase()} size={36} />
            <button onClick={logoutUser} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--brown-light)", fontSize: 13 }}>Logout</button>
          </>
        ) : (
          <>
            <button onClick={() => navigate("auth", { mode: "login" })} className="btn btn-outline btn-sm hide-mobile">Sign In</button>
            <button onClick={() => navigate("auth", { mode: "register" })} className="btn btn-primary btn-sm">Join Free</button>
          </>
        )}
        {/* Hamburger */}
        <button className="hide-desktop" onClick={() => setMenuOpen(!menuOpen)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 22, color: "var(--brown-dark)" }}>
          {menuOpen ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <>
          <div className="overlay" onClick={() => setMenuOpen(false)} />
          <div className="sidebar" style={{ padding: 24 }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 700, marginBottom: 24 }}>Menu</div>
            {navLinks.map(l => (
              <button key={l.label} onClick={() => { navigate(l.page); setMenuOpen(false); }} style={{ display: "block", width: "100%", padding: "14px 0", background: "none", border: "none", borderBottom: "1px solid var(--sand)", textAlign: "left", fontSize: 16, color: "var(--brown-dark)", cursor: "pointer", fontFamily: "var(--font-body)" }}>
                {l.label}
              </button>
            ))}
          </div>
        </>
      )}
    </nav>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
function HomePage() {
  const { navigate, cacheSearch } = useApp();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    const results = DESTINATIONS.filter(d =>
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.type.toLowerCase().includes(searchQuery.toLowerCase())
    );
    cacheSearch(searchQuery, results);
    navigate("search", { query: searchQuery, results });
  };

  const featuredDests = DESTINATIONS;
  const featuredAgencies = AGENCIES.slice(0, 4);

  return (
    <div>
      {/* HERO */}
      <div style={{ position: "relative", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
        {/* BG */}
        <div style={{ position: "absolute", inset: 0, background: "url(https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1600&q=80&auto=format&fit=crop" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(44,24,16,0.55) 0%, rgba(44,24,16,0.7) 60%, rgba(44,24,16,0.85) 100%)" }} />

        {/* Decorative circles */}
        <div style={{ position: "absolute", top: "15%", right: "10%", width: 300, height: 300, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.1)", animation: "pulse 4s ease infinite" }} />
        <div style={{ position: "absolute", bottom: "20%", left: "8%", width: 180, height: 180, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.08)" }} />

        <div style={{ position: "relative", textAlign: "center", padding: "0 24px", maxWidth: 780, margin: "0 auto", animation: "fadeUp 0.8s ease" }}>
          <div className="badge badge-gold" style={{ marginBottom: 20, display: "inline-flex" }}>
            🇮🇳 India's #1 Multi-Agency Travel Platform
          </div>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2.5rem, 7vw, 5rem)", fontWeight: 900, color: "#fff", lineHeight: 1.1, marginBottom: 20 }}>
            Discover the Soul<br />
            <span style={{ color: "var(--gold-light)" }}>of Incredible India</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: "clamp(1rem, 2.5vw, 1.2rem)", marginBottom: 40, lineHeight: 1.7 }}>
            Compare 500+ agencies, explore 1000+ packages, and book your perfect Indian adventure — all in one place.
          </p>

          {/* Search Bar */}
          <div style={{ display: "flex", gap: 8, background: "rgba(255,255,255,0.97)", borderRadius: "var(--radius-xl)", padding: "8px 8px 8px 24px", boxShadow: "0 20px 60px rgba(0,0,0,0.3)", maxWidth: 600, margin: "0 auto 40px" }}>
            <span style={{ fontSize: 20, alignSelf: "center" }}>🔍</span>
            <input
              className="input"
              style={{ border: "none", background: "transparent", flex: 1, fontSize: 16, padding: "8px 0" }}
              placeholder="Search Rajasthan, Kerala, Ladakh..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSearch()}
            />
            <button className="btn btn-primary btn-lg" onClick={handleSearch} style={{ borderRadius: "var(--radius-xl)", whiteSpace: "nowrap" }}>
              Explore Now
            </button>
          </div>

          {/* Quick tags */}
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center" }}>
            {["🏖 Beach", "🏔 Adventure", "🛕 Heritage", "🌿 Nature", "🙏 Spiritual"].map(t => (
              <button key={t} onClick={() => { setSearchQuery(t.split(" ")[1]); }} className="btn btn-ghost btn-sm" style={{ borderRadius: 99 }}>{t}</button>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{ position: "absolute", bottom: 32, left: "50%", transform: "translateX(-50%)", color: "rgba(255,255,255,0.5)", fontSize: 24, animation: "bounce 2s ease infinite" }}>↓</div>
      </div>

      {/* STATS */}
      <div style={{ background: "var(--brown-dark)", padding: "32px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 24, textAlign: "center" }}>
          {[["500+", "Travel Agencies"], ["1000+", "Packages"], ["50k+", "Happy Travelers"], ["28", "States Covered"]].map(([num, label]) => (
            <div key={label}>
              <div style={{ fontFamily: "var(--font-display)", fontSize: 36, fontWeight: 900, color: "var(--gold-light)" }}>{num}</div>
              <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 13 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* FEATURED DESTINATIONS */}
      <div style={{ padding: "80px 24px", maxWidth: 1300, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 48, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div className="badge badge-terra" style={{ marginBottom: 12 }}>Featured Destinations</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.8rem, 4vw, 3rem)", fontWeight: 700, color: "var(--brown-dark)" }}>
              Where Would You Go?
            </h2>
            <p style={{ color: "var(--brown-light)", marginTop: 8 }}>{DESTINATIONS.length} hand-picked destinations · 96 iconic tourist places</p>
          </div>
          <button className="btn btn-outline" onClick={() => navigate("destinations")}>View All →</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 24 }}>
          {featuredDests.map((d, i) => (
            <div key={d.id} className="card" style={{ cursor: "pointer", animationDelay: `${i * 0.08}s` }} onClick={() => navigate("destination", { destId: d.id })}>
              <div style={{ position: "relative", paddingBottom: "62%", overflow: "hidden" }}>
                <Img src={d.img} alt={d.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.5s ease" }} onMouseEnter={e => e.target.style.transform = "scale(1.07)"} onMouseLeave={e => e.target.style.transform = "scale(1)"} />
                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(44,24,16,0.75) 0%, transparent 55%)" }} />
                <div style={{ position: "absolute", bottom: 16, left: 16 }}>
                  <div style={{ color: "#fff", fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 700 }}>{d.name}</div>
                  <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 13 }}>{d.state}</div>
                </div>
                <div style={{ position: "absolute", top: 12, right: 12 }}>
                  <RiskBadge risk={d.risk} />
                </div>
                <div style={{ position: "absolute", top: 12, left: 12, background: "rgba(0,0,0,0.45)", color: "#fff", fontSize: 12, padding: "4px 10px", borderRadius: 99, backdropFilter: "blur(4px)" }}>
                  📸 {d.places?.length || 0} places
                </div>
              </div>
              <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontSize: 13, color: "var(--brown-light)", marginBottom: 4 }}>{d.tagline}</div>
                  <span className={`badge badge-${d.type === "adventure" ? "terra" : d.type === "beach" ? "blue" : "green"}`}>{d.type}</span>
                </div>
                <button className="btn btn-primary btn-sm" onClick={e => { e.stopPropagation(); navigate("destination", { destId: d.id }); }}>See Places →</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* WHY TRAVELHUB */}
      <div style={{ background: "var(--cream)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <div className="badge badge-green" style={{ marginBottom: 12 }}>Why TravelHub?</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.8rem, 4vw, 3rem)", fontWeight: 700 }}>
              Travel Smarter, Not Harder
            </h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 32 }}>
            {[
              { icon: "🤖", title: "AI Travel Search", desc: "Type your dream trip in plain English — Gemini AI finds the perfect packages instantly.", page: "aisearch" },
              { icon: "🧬", title: "Travel DNA Quiz", desc: "5 quick questions to discover your traveler persona and get matched packages.", page: "dna" },
              { icon: "🏕️", title: "Group Trip Planner", desc: "Create a room, invite friends, add packages, and vote on your next destination together.", page: "triproom" },
              { icon: "🗺️", title: "Live Map Explorer", desc: "Search any destination on India's interactive map with real-time agency markers.", page: "map" },
              { icon: "⚠️", title: "Risk Analytics", desc: "AI-powered risk scores for every destination based on weather, crowd & safety data.", page: "destinations" },
              { icon: "📡", title: "Offline Mode", desc: "Cache your searches and browse even without an internet connection.", page: "search" },
            ].map(f => (
              <div key={f.title} onClick={() => navigate(f.page)} style={{ textAlign: "center", padding: 32, background: "#fff", borderRadius: "var(--radius-lg)", boxShadow: "var(--shadow-sm)", transition: "all 0.3s", cursor: "pointer" }} onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-6px)"; e.currentTarget.style.boxShadow = "var(--shadow-lg)"; }} onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "var(--shadow-sm)"; }}>
                <div style={{ fontSize: 44, marginBottom: 16 }}>{f.icon}</div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 700, marginBottom: 10, color: "var(--brown-dark)" }}>{f.title}</div>
                <div style={{ color: "var(--brown-light)", lineHeight: 1.6, fontSize: 14 }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FEATURED AGENCIES */}
      <div style={{ padding: "80px 24px", maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 48, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div className="badge badge-gold" style={{ marginBottom: 12 }}>Top Rated</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.8rem, 4vw, 3rem)", fontWeight: 700 }}>Featured Agencies</h2>
          </div>
          <button className="btn btn-outline" onClick={() => navigate("agencies")}>View All →</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 24 }}>
          {featuredAgencies.map(a => <AgencyCard key={a.id} agency={a} />)}
        </div>
      </div>

      {/* MAP TEASER */}
      <div style={{ background: "var(--brown-dark)", padding: "80px 24px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, opacity: 0.1 }}>
          <IndiaMapSVG simple />
        </div>
        <div style={{ position: "relative", textAlign: "center", maxWidth: 600, margin: "0 auto" }}>
          <div style={{ fontSize: 60, marginBottom: 20 }}>🗺️</div>
          <h2 style={{ fontFamily: "var(--font-display)", color: "#fff", fontSize: "clamp(1.8rem, 4vw, 2.8rem)", fontWeight: 700, marginBottom: 16 }}>
            Explore India on the Map
          </h2>
          <p style={{ color: "rgba(255,255,255,0.7)", marginBottom: 32, lineHeight: 1.7 }}>
            Click any state, find agencies, compare packages, and check risk ratings — all on our interactive India map.
          </p>
          <button className="btn btn-secondary btn-lg" onClick={() => navigate("map")}>Open Map Explorer</button>
        </div>
      </div>

      {/* FOOTER */}
      <Footer />
    </div>
  );
}

// ─── INDIA MAP SVG (simplified decorative) ───────────────────────────────────
function IndiaMapSVG({ simple = false, markers = [], onMarkerClick }) {
  if (simple) return (
    <svg viewBox="0 0 500 600" style={{ width: "100%", height: "100%", fill: "var(--cream)", stroke: "var(--sand)", strokeWidth: 1 }}>
      <path d="M200,50 L280,60 L340,100 L380,150 L360,200 L400,240 L420,300 L390,360 L350,400 L300,440 L260,480 L220,500 L200,480 L180,440 L160,400 L140,360 L120,300 L100,240 L80,180 L100,130 L140,90 Z" />
    </svg>
  );
  return (
    <div style={{ position: "relative", width: "100%", maxWidth: 600, margin: "0 auto" }}>
      <svg viewBox="0 0 500 580" style={{ width: "100%", fill: "var(--cream)", stroke: "var(--brown-light)", strokeWidth: 0.8 }}>
        {/* Simplified India outline */}
        <path d="M180,40 L210,35 L250,38 L290,45 L330,55 L360,80 L380,110 L390,145 L375,170 L385,200 L410,230 L425,265 L420,300 L405,340 L380,380 L350,420 L320,450 L290,480 L265,510 L245,530 L230,520 L215,495 L200,460 L185,430 L165,395 L145,355 L130,310 L120,265 L110,220 L105,175 L110,140 L125,110 L145,85 L165,62 Z" fill="rgba(232,223,208,0.5)" />
        {/* Northeast */}
        <path d="M330,55 L360,50 L385,60 L400,80 L380,110 L360,80 Z" fill="rgba(232,223,208,0.5)" />
        {/* Kashmir */}
        <path d="M180,40 L200,25 L230,20 L260,25 L290,35 L290,45 L250,38 L210,35 Z" fill="rgba(232,223,208,0.5)" />
      </svg>
      {/* Markers */}
      {markers.map(m => {
        // Convert lat/lng to SVG coords (very approximate)
        const x = ((m.lng - 68) / (98 - 68)) * 420 + 40;
        const y = ((37 - m.lat) / (37 - 8)) * 500 + 30;
        return (
          <div key={m.id} onClick={() => onMarkerClick && onMarkerClick(m)} style={{
            position: "absolute", left: `${(x / 500) * 100}%`, top: `${(y / 580) * 100}%`,
            transform: "translate(-50%,-100%)", cursor: "pointer",
            animation: "bounce 2s ease infinite",
          }}>
            <div style={{ background: m.selected ? "var(--terracotta)" : "var(--forest-mid)", color: "#fff", borderRadius: "var(--radius-md)", padding: "6px 10px", fontSize: 11, whiteSpace: "nowrap", boxShadow: "0 4px 12px rgba(0,0,0,0.3)", fontWeight: 600 }}>
              📍 {m.label}
              <br />
              <span style={{ fontSize: 10, opacity: 0.85 }}>₹{m.price?.toLocaleString()} · ⭐{m.rating}</span>
            </div>
            <div style={{ width: 8, height: 8, background: m.selected ? "var(--terracotta)" : "var(--forest-mid)", borderRadius: "50%", margin: "2px auto 0", boxShadow: "0 0 0 4px rgba(45,80,22,0.2)" }} />
          </div>
        );
      })}
    </div>
  );
}

// ─── MAP PAGE ─────────────────────────────────────────────────────────────────
function MapPage() {
  const { navigate } = useApp();
  const [selectedDest, setSelectedDest] = useState(null);
  const [searchQ, setSearchQ] = useState("");
  const [filtered, setFiltered] = useState(DESTINATIONS);

  const handleSearch = () => {
    const f = DESTINATIONS.filter(d =>
      d.name.toLowerCase().includes(searchQ.toLowerCase()) ||
      d.state.toLowerCase().includes(searchQ.toLowerCase())
    );
    setFiltered(f.length ? f : DESTINATIONS);
  };

  const markers = filtered.map(d => {
    const coords = DEST_COORDS[d.id] || { lat: 20, lng: 78 };
    const agency = AGENCIES.find(a => a.dest.includes(d.id));
    return {
      id: d.id, label: d.name, lat: coords.lat, lng: coords.lng,
      price: agency?.price, rating: agency?.rating,
      risk: d.risk, selected: selectedDest?.id === d.id,
    };
  });

  const selAgencies = selectedDest ? AGENCIES.filter(a => a.dest.includes(selectedDest.id)) : [];

  return (
    <div style={{ paddingTop: 68, minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ background: "var(--brown-dark)", padding: "24px", display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <h1 style={{ fontFamily: "var(--font-display)", color: "#fff", fontSize: 24, fontWeight: 700 }}>🗺️ Map Explorer</h1>
        <div style={{ display: "flex", gap: 8, flex: 1, maxWidth: 400 }}>
          <input className="input" value={searchQ} onChange={e => setSearchQ(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSearch()} placeholder="Search destination on map..." style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff" }} />
          <button className="btn btn-secondary" onClick={handleSearch}>Search</button>
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", gap: 0 }}>
        {/* Map */}
        <div style={{ flex: 1, background: "#E8DFD0", position: "relative", minHeight: 500, padding: 24 }}>
          <div style={{ maxWidth: 600, margin: "0 auto" }}>
            <IndiaMapSVG markers={markers} onMarkerClick={m => setSelectedDest(DESTINATIONS.find(d => d.id === m.id))} />
          </div>
          <div style={{ position: "absolute", bottom: 16, left: 16, background: "white", borderRadius: "var(--radius-md)", padding: "12px 16px", fontSize: 12, boxShadow: "var(--shadow-sm)" }}>
            <div style={{ fontWeight: 600, marginBottom: 6 }}>Legend</div>
            <div style={{ display: "flex", gap: 12 }}>
              <span>🟢 Low Risk</span><span>🟡 Moderate</span><span>🔴 High Risk</span>
            </div>
          </div>
        </div>

        {/* Side panel */}
        <div style={{ width: 320, background: "#fff", borderLeft: "1px solid var(--sand)", overflow: "auto", maxHeight: "calc(100vh - 68px - 88px)", position: "sticky", top: 68 }}>
          {selectedDest ? (
            <div>
              <Img src={selectedDest.img} alt={selectedDest.name} style={{ width: "100%", height: 160, objectFit: "cover" }} />
              <div style={{ padding: 20 }}>
                <h2 style={{ fontFamily: "var(--font-display)", fontSize: 22, marginBottom: 6 }}>{selectedDest.name}</h2>
                <div style={{ color: "var(--brown-light)", fontSize: 13, marginBottom: 12 }}>{selectedDest.state}</div>
                <RiskBadge risk={selectedDest.risk} />
                <div style={{ marginTop: 16, padding: 14, background: "var(--cream)", borderRadius: "var(--radius-md)", marginBottom: 16 }}>
                  <div style={{ fontWeight: 600, marginBottom: 8, fontSize: 13 }}>Risk Analysis</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, textAlign: "center" }}>
                    {[["🌤", "Weather", "Good"], ["👥", "Crowd", selectedDest.risk > 30 ? "High" : "Moderate"], ["🛡", "Safety", selectedDest.risk < 20 ? "Good" : "Fair"]].map(([icon, label, val]) => (
                      <div key={label} style={{ padding: 8, background: "#fff", borderRadius: 8 }}>
                        <div style={{ fontSize: 20 }}>{icon}</div>
                        <div style={{ fontSize: 10, color: "var(--brown-light)" }}>{label}</div>
                        <div style={{ fontSize: 12, fontWeight: 600 }}>{val}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div style={{ fontWeight: 600, marginBottom: 10 }}>Available Agencies ({selAgencies.length})</div>
                {selAgencies.map(a => (
                  <div key={a.id} onClick={() => navigate("agency", { agencyId: a.id })} style={{ padding: "12px", border: "1px solid var(--sand)", borderRadius: "var(--radius-sm)", marginBottom: 8, cursor: "pointer", transition: "all 0.2s" }} onMouseEnter={e => e.currentTarget.style.background = "var(--cream)"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{a.name}</div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                      <Stars rating={a.rating} size={12} />
                      <span style={{ fontSize: 13, color: "var(--terracotta)", fontWeight: 600 }}>₹{a.price.toLocaleString()}+</span>
                    </div>
                  </div>
                ))}
                <button className="btn btn-primary" style={{ width: "100%" }} onClick={() => navigate("search", { query: selectedDest.name, destId: selectedDest.id })}>
                  View All Packages
                </button>
              </div>
            </div>
          ) : (
            <div style={{ padding: 24, textAlign: "center", color: "var(--brown-light)", marginTop: 40 }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>🗺️</div>
              <p>Click any marker on the map to explore destination details, agencies, and risk analysis.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── AGENCY CARD ──────────────────────────────────────────────────────────────
function AgencyCard({ agency }) {
  const { navigate } = useApp();
  return (
    <div className="card" onClick={() => navigate("agency", { agencyId: agency.id })} style={{ cursor: "pointer" }}>
      <div style={{ position: "relative", paddingBottom: "56%", overflow: "hidden" }}>
        <Img src={agency.img} alt={agency.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.4s" }} onMouseEnter={e => e.target.style.transform = "scale(1.07)"} onMouseLeave={e => e.target.style.transform = "scale(1)"} />
        {agency.verified && (
          <div style={{ position: "absolute", top: 12, right: 12 }}>
            <span className="badge badge-green">✓ Verified</span>
          </div>
        )}
      </div>
      <div style={{ padding: "18px 20px" }}>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 17, fontWeight: 700, marginBottom: 6 }}>{agency.name}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
          <Stars rating={agency.rating} />
          <span style={{ fontSize: 13, color: "var(--brown-light)" }}>{agency.rating} ({agency.reviews} reviews)</span>
        </div>
        <p style={{ fontSize: 13, color: "var(--brown-light)", lineHeight: 1.5, marginBottom: 12 }}>{agency.desc}</p>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <span style={{ fontSize: 11, color: "var(--brown-light)" }}>Starting from</span>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 20, fontWeight: 700, color: "var(--terracotta)" }}>₹{agency.price.toLocaleString()}</div>
          </div>
          <button className="btn btn-primary btn-sm">View Details →</button>
        </div>
      </div>
    </div>
  );
}

// ─── SEARCH/DESTINATION PAGE ──────────────────────────────────────────────────
function SearchPage() {
  const { navigate, pageParams, cacheSearch, cachedSearches, isOffline } = useApp();
  const [query, setQuery] = useState(pageParams.query || "");
  const [results, setResults] = useState(pageParams.results || DESTINATIONS);
  const [agencies, setAgencies] = useState([]);
  const [priceFilter, setPriceFilter] = useState([0, 100000]);
  const [ratingFilter, setRatingFilter] = useState(0);
  const [typeFilter, setTypeFilter] = useState("all");
  const [sortBy, setSortBy] = useState("rating");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (pageParams.results) {
      setResults(pageParams.results);
      setQuery(pageParams.query || "");
    }
    if (pageParams.destId) {
      const destAgencies = AGENCIES.filter(a => a.dest.includes(pageParams.destId));
      setAgencies(destAgencies);
    } else {
      setAgencies(AGENCIES);
    }
  }, [pageParams]);

  const handleSearch = () => {
    if (!query.trim()) { setResults(DESTINATIONS); setAgencies(AGENCIES); return; }
    setLoading(true);
    setTimeout(() => {
      let res = DESTINATIONS.filter(d =>
        d.name.toLowerCase().includes(query.toLowerCase()) ||
        d.state.toLowerCase().includes(query.toLowerCase()) ||
        d.type.toLowerCase().includes(query.toLowerCase()) ||
        d.tagline.toLowerCase().includes(query.toLowerCase())
      );
      if (!res.length) res = DESTINATIONS;
      setResults(res);
      const destIds = res.map(d => d.id);
      setAgencies(AGENCIES.filter(a => a.dest.some(id => destIds.includes(id))));
      cacheSearch(query, res);
      setLoading(false);
    }, 600);
  };

  let filteredAgencies = agencies
    .filter(a => a.price >= priceFilter[0] && a.price <= priceFilter[1])
    .filter(a => a.rating >= ratingFilter)
    .filter(a => typeFilter === "all" || a.type === typeFilter)
    .sort((a, b) => sortBy === "price" ? a.price - b.price : b.rating - a.rating);

  return (
    <div style={{ paddingTop: 68 }}>
      {/* Search header */}
      <div style={{ background: "var(--cream)", padding: "32px 24px", borderBottom: "1px solid var(--sand)" }}>
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          {isOffline && (
            <div style={{ background: "#FFF4DE", border: "1px solid var(--gold)", borderRadius: "var(--radius-md)", padding: "10px 16px", marginBottom: 16, fontSize: 13, display: "flex", alignItems: "center", gap: 8 }}>
              📡 <strong>Offline Mode</strong> — Showing {cachedSearches.length ? "cached" : "default"} results. Connect to see live data.
            </div>
          )}
          <div style={{ display: "flex", gap: 8 }}>
            <input className="input" value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSearch()} placeholder="Search destination, state, type..." style={{ flex: 1, fontSize: 16 }} />
            <button className="btn btn-primary" onClick={handleSearch}>🔍 Search</button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "32px 24px", display: "grid", gridTemplateColumns: "260px 1fr", gap: 32, alignItems: "start" }}>

        {/* Filters */}
        <div className="card hide-mobile" style={{ padding: 24, position: "sticky", top: 84 }}>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Filters</div>

          <div style={{ marginBottom: 20 }}>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 10 }}>Type</div>
            {["all", "budget", "luxury", "adventure", "spiritual", "nature"].map(t => (
              <label key={t} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, cursor: "pointer", fontSize: 14 }}>
                <input type="radio" name="type" checked={typeFilter === t} onChange={() => setTypeFilter(t)} style={{ accentColor: "var(--forest-mid)" }} />
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </label>
            ))}
          </div>

          <div style={{ marginBottom: 20 }}>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 10 }}>Minimum Rating</div>
            {[0, 3, 4, 4.5].map(r => (
              <label key={r} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, cursor: "pointer", fontSize: 14 }}>
                <input type="radio" name="rating" checked={ratingFilter === r} onChange={() => setRatingFilter(r)} style={{ accentColor: "var(--forest-mid)" }} />
                {r === 0 ? "Any" : `${r}+ ⭐`}
              </label>
            ))}
          </div>

          <div>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 10 }}>Max Price: ₹{priceFilter[1].toLocaleString()}</div>
            <input type="range" min={5000} max={100000} step={1000} value={priceFilter[1]} onChange={e => setPriceFilter([0, +e.target.value])} style={{ width: "100%", accentColor: "var(--forest-mid)" }} />
          </div>

          <div style={{ marginTop: 20 }}>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 10 }}>Sort By</div>
            <select className="input" value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: "8px 12px", fontSize: 14 }}>
              <option value="rating">Top Rated</option>
              <option value="price">Lowest Price</option>
            </select>
          </div>

          <button className="btn btn-outline" style={{ width: "100%", marginTop: 16 }} onClick={() => { setTypeFilter("all"); setRatingFilter(0); setPriceFilter([0, 100000]); }}>Reset Filters</button>
        </div>

        {/* Results */}
        <div>
          {/* Destinations */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24, fontWeight: 700 }}>
                {results.length} Destination{results.length !== 1 ? "s" : ""} Found
              </h2>
            </div>
            <div className="scroll-x" style={{ display: "flex", gap: 16, paddingBottom: 8 }}>
              {results.map(d => (
                <div key={d.id} onClick={() => { const a = AGENCIES.filter(ag => ag.dest.includes(d.id)); setAgencies(a.length ? a : AGENCIES); }} style={{ flexShrink: 0, width: 160, cursor: "pointer" }}>
                  <div style={{ borderRadius: "var(--radius-md)", overflow: "hidden", position: "relative", paddingBottom: "70%" }}>
                    <Img src={d.img} alt={d.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
                    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 50%)" }} />
                    <div style={{ position: "absolute", bottom: 8, left: 8, color: "#fff", fontSize: 13, fontWeight: 600 }}>{d.name}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Agency cards */}
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16, alignItems: "center" }}>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24, fontWeight: 700 }}>
              {filteredAgencies.length} Agenc{filteredAgencies.length !== 1 ? "ies" : "y"}
            </h2>
            <span style={{ fontSize: 13, color: "var(--brown-light)" }}>{filteredAgencies.length} results</span>
          </div>
          {loading ? <Loader /> : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
              {filteredAgencies.map(a => <AgencyCard key={a.id} agency={a} />)}
              {!filteredAgencies.length && (
                <div style={{ gridColumn: "1/-1", textAlign: "center", padding: 60, color: "var(--brown-light)" }}>
                  <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
                  <p>No agencies match your filters. Try adjusting them.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── AGENCY DETAIL PAGE ───────────────────────────────────────────────────────
function AgencyDetailPage() {
  const { navigate, pageParams } = useApp();
  const agency = AGENCIES.find(a => a.id === pageParams.agencyId) || AGENCIES[0];
  const packages = PACKAGES.filter(p => p.agencyId === agency.id);
  const agencyReviews = REVIEWS.filter(r => r.agencyId === agency.id);
  const destinations = DESTINATIONS.filter(d => agency.dest.includes(d.id));
  const [tab, setTab] = useState("packages");

  return (
    <div style={{ paddingTop: 68 }}>
      {/* Banner */}
      <div style={{ position: "relative", height: 320, overflow: "hidden" }}>
        <Img src={agency.img} alt={agency.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 40%, rgba(44,24,16,0.85))" }} />
        <div style={{ position: "absolute", bottom: 32, left: 32 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
            <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 4vw, 2.5rem)", fontWeight: 900, color: "#fff" }}>{agency.name}</h1>
            {agency.verified && <span className="badge badge-green">✓ Verified</span>}
          </div>
          <div style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
            <Stars rating={agency.rating} size={18} />
            <span style={{ color: "rgba(255,255,255,0.8)", fontSize: 14 }}>{agency.rating} ({agency.reviews} reviews)</span>
            <span className="badge badge-gold">₹{agency.price.toLocaleString()}+ starting</span>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 24, marginBottom: 32, alignItems: "start" }}>
          <div>
            <p style={{ fontSize: 16, lineHeight: 1.7, color: "var(--brown-mid)", maxWidth: 600 }}>{agency.desc}</p>
            <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
              {destinations.map(d => <span key={d.id} className="badge badge-blue">{d.name}</span>)}
              <span className={`badge badge-${agency.type === "luxury" ? "gold" : agency.type === "adventure" ? "terra" : "green"}`}>{agency.type}</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, flexDirection: "column" }}>
            <button className="btn btn-primary" onClick={() => navigate("chat", { agencyId: agency.id })}>💬 Chat with Agency</button>
            <button className="btn btn-secondary" onClick={() => navigate("booking", { agencyId: agency.id, packageId: packages[0]?.id })}>📅 Book Now</button>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, borderBottom: "2px solid var(--sand)", marginBottom: 32 }}>
          {["packages", "gallery", "reviews"].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ padding: "12px 20px", background: "none", border: "none", borderBottom: tab === t ? "2px solid var(--forest-mid)" : "2px solid transparent", marginBottom: -2, color: tab === t ? "var(--forest-mid)" : "var(--brown-light)", fontWeight: tab === t ? 600 : 400, cursor: "pointer", textTransform: "capitalize", fontSize: 15, fontFamily: "var(--font-body)" }}>
              {t === "packages" ? `📦 Packages (${packages.length})` : t === "gallery" ? "🖼 Gallery" : `⭐ Reviews (${agencyReviews.length})`}
            </button>
          ))}
        </div>

        {tab === "packages" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 24 }}>
            {packages.length ? packages.map(p => <PackageCard key={p.id} pkg={p} />) : (
              <p style={{ color: "var(--brown-light)" }}>No packages listed yet.</p>
            )}
          </div>
        )}

        {tab === "gallery" && (
          <div>
            {destinations.map(dest => (
              <div key={dest.id} style={{ marginBottom: 40 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
                  <Img src={dest.img} alt={dest.name} style={{ width: 56, height: 56, objectFit: "cover", borderRadius: "var(--radius-sm)" }} />
                  <div>
                    <h3 style={{ fontFamily: "var(--font-display)", fontSize: 20, fontWeight: 700 }}>{dest.name}</h3>
                    <p style={{ fontSize: 13, color: "var(--brown-light)" }}>{dest.about?.slice(0, 100)}...</p>
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 16 }}>
                  {(dest.places || []).map((place, i) => (
                    <div key={i} style={{ borderRadius: "var(--radius-md)", overflow: "hidden", position: "relative", cursor: "pointer", boxShadow: "var(--shadow-sm)", transition: "transform 0.3s, box-shadow 0.3s" }} onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = "var(--shadow-lg)"; }} onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "var(--shadow-sm)"; }}>
                      <div style={{ paddingBottom: "68%", position: "relative" }}>
                        <Img src={place.img} alt={place.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
                        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(44,24,16,0.75) 0%, transparent 55%)" }} />
                      </div>
                      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "12px 14px" }}>
                        <div style={{ color: "#fff", fontWeight: 700, fontSize: 13, marginBottom: 2 }}>{place.name}</div>
                        <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 11, lineHeight: 1.4 }}>{place.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "reviews" && (
          <div>
            <ReviewsSection reviews={agencyReviews} agencyId={agency.id} />
          </div>
        )}
      </div>
    </div>
  );
}

// ─── PACKAGE CARD ─────────────────────────────────────────────────────────────
function PackageCard({ pkg }) {
  const { navigate } = useApp();
  return (
    <div className="card" style={{ cursor: "pointer" }} onClick={() => navigate("package", { packageId: pkg.id })}>
      <div style={{ position: "relative", paddingBottom: "56%", overflow: "hidden" }}>
        <Img src={pkg.img} alt={pkg.title} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.4s" }} onMouseEnter={e => e.target.style.transform = "scale(1.07)"} onMouseLeave={e => e.target.style.transform = "scale(1)"} />
        <span className={`badge badge-${pkg.type === "luxury" ? "gold" : pkg.type === "adventure" ? "terra" : "green"}`} style={{ position: "absolute", top: 12, left: 12 }}>{pkg.type}</span>
      </div>
      <div style={{ padding: "18px 20px" }}>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>{pkg.title}</div>
        <div style={{ color: "var(--brown-light)", fontSize: 13, marginBottom: 12 }}>⏱ {pkg.duration}</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <span style={{ fontSize: 11, color: "var(--brown-light)" }}>Per person</span>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 700, color: "var(--terracotta)" }}>₹{pkg.price.toLocaleString()}</div>
          </div>
          <button className="btn btn-primary btn-sm">View →</button>
        </div>
      </div>
    </div>
  );
}

// ─── PACKAGE DETAIL PAGE ──────────────────────────────────────────────────────
function PackageDetailPage() {
  const { navigate, pageParams } = useApp();
  const pkg = PACKAGES.find(p => p.id === pageParams.packageId) || PACKAGES[0];
  const agency = AGENCIES.find(a => a.id === pkg.agencyId);

  return (
    <div style={{ paddingTop: 68 }}>
      <div style={{ position: "relative", height: 360, overflow: "hidden" }}>
        <Img src={pkg.img} alt={pkg.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent, rgba(44,24,16,0.8))" }} />
        <div style={{ position: "absolute", bottom: 32, left: 32, right: 32 }}>
          <span className={`badge badge-${pkg.type === "luxury" ? "gold" : "terra"}`} style={{ marginBottom: 12 }}>{pkg.type}</span>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 4vw, 2.8rem)", fontWeight: 900, color: "#fff", marginBottom: 8 }}>{pkg.title}</h1>
          <div style={{ display: "flex", gap: 20, color: "rgba(255,255,255,0.85)", fontSize: 14, flexWrap: "wrap" }}>
            <span>⏱ {pkg.duration}</span>
            {agency && <span>🏢 {agency.name}</span>}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px", display: "grid", gridTemplateColumns: "1fr 340px", gap: 40, alignItems: "start" }}>
        <div>
          {/* Itinerary */}
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24, marginBottom: 20 }}>Day-wise Itinerary</h2>
          <div style={{ marginBottom: 40 }}>
            {pkg.itinerary.map((day, i) => (
              <div key={i} style={{ display: "flex", gap: 16, marginBottom: 16 }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%", background: "var(--forest-mid)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{i + 1}</div>
                <div style={{ flex: 1, paddingTop: 7 }}>
                  <div style={{ fontWeight: 500, fontSize: 14, lineHeight: 1.5 }}>{day}</div>
                  {i < pkg.itinerary.length - 1 && <div style={{ width: 2, height: 16, background: "var(--sand)", margin: "8px 0 -8px -26px" }} />}
                </div>
              </div>
            ))}
          </div>

          {/* Inclusions */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            <div style={{ padding: 20, background: "#E8F5E3", borderRadius: "var(--radius-md)" }}>
              <h3 style={{ fontFamily: "var(--font-display)", fontSize: 18, marginBottom: 12, color: "var(--forest)" }}>✅ Inclusions</h3>
              {pkg.inclusions.map((item, i) => <div key={i} style={{ fontSize: 14, marginBottom: 8, display: "flex", gap: 8 }}>✓ {item}</div>)}
            </div>
            <div style={{ padding: 20, background: "#FFE8E5", borderRadius: "var(--radius-md)" }}>
              <h3 style={{ fontFamily: "var(--font-display)", fontSize: 18, marginBottom: 12, color: "var(--risk-high)" }}>❌ Exclusions</h3>
              {pkg.exclusions.map((item, i) => <div key={i} style={{ fontSize: 14, marginBottom: 8, display: "flex", gap: 8 }}>✗ {item}</div>)}
            </div>
          </div>
        </div>

        {/* Sticky CTA */}
        <div className="card" style={{ padding: 28, position: "sticky", top: 84 }}>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 36, fontWeight: 900, color: "var(--terracotta)", marginBottom: 4 }}>
            ₹{pkg.price.toLocaleString()}
          </div>
          <div style={{ color: "var(--brown-light)", fontSize: 13, marginBottom: 20 }}>per person · {pkg.duration}</div>

          {agency && (
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderTop: "1px solid var(--sand)", borderBottom: "1px solid var(--sand)", marginBottom: 20 }}>
              <div style={{ width: 40, height: 40, borderRadius: "var(--radius-sm)", overflow: "hidden" }}>
                <Img src={agency.img} alt={agency.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{agency.name}</div>
                <div style={{ display: "flex", gap: 4 }}><Stars rating={agency.rating} size={12} /><span style={{ fontSize: 12, color: "var(--brown-light)" }}>{agency.rating}</span></div>
              </div>
            </div>
          )}

          <button className="btn btn-primary" style={{ width: "100%", marginBottom: 10, justifyContent: "center" }} onClick={() => navigate("booking", { packageId: pkg.id, agencyId: pkg.agencyId })}>
            📅 Book This Package
          </button>
          <button className="btn btn-outline" style={{ width: "100%", justifyContent: "center" }} onClick={() => navigate("chat", { agencyId: pkg.agencyId })}>
            💬 Chat with Agency
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── BOOKING PAGE ─────────────────────────────────────────────────────────────
function BookingPage() {
  const { navigate, pageParams, setBookings, addNotification, user } = useApp();
  const pkg = PACKAGES.find(p => p.id === pageParams.packageId) || PACKAGES[0];
  const agency = AGENCIES.find(a => a.id === (pageParams.agencyId || pkg?.agencyId));
  const [form, setForm] = useState({ name: user?.name || "", email: user?.email || "", phone: "", travelers: 1, date: "" });
  const [submitted, setSubmitted] = useState(null);

  const handleSubmit = async () => {
    if (!form.name || !form.email || !form.date) { alert("Please fill all required fields"); return; }
    try {
      let booking;
      // Try real backend first
      const bookingData = {
        package_id: pkg?.id || 1,
        agency_id: agency?.id || 1,
        traveler_name: form.name,
        traveler_email: form.email,
        traveler_phone: form.phone,
        travel_date: form.date,
        num_travelers: form.travelers,
        num_children: 0,
        room_type: "shared",
      };
      try {
        booking = await bookingsAPI.create(bookingData);
      } catch {
        // Fallback: create local booking if backend unreachable
        booking = { id: Date.now(), reference: "TH-" + Math.floor(10000 + Math.random() * 90000), ...bookingData, total_price: (pkg?.price || 0) * form.travelers, status: "confirmed" };
      }
      setBookings(prev => [...prev, { ...booking, pkg, agency, form }]);
      addNotification("Booking confirmed! Ref: " + booking.reference);
      setSubmitted(booking);
    } catch (e) {
      alert("Booking failed: " + e.message);
    }
  };

  if (submitted) return (
    <div style={{ paddingTop: 68, minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center", padding: 48, maxWidth: 480 }} className="fade-up">
        <div style={{ fontSize: 80, marginBottom: 24 }}>🎉</div>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 32, marginBottom: 12 }}>Booking Confirmed!</h1>
        <p style={{ color: "var(--brown-light)", marginBottom: 8 }}>A confirmation has been sent to <strong>{form.email}</strong></p>
        <p style={{ color: "var(--brown-light)", marginBottom: 8, fontSize: 14 }}>Booking Reference: <strong style={{ color: "var(--forest-mid)" }}>{submitted.reference || "TH-" + submitted.id}</strong></p>
        <p style={{ color: "var(--brown-light)", marginBottom: 32, fontSize: 14 }}>Travel Date: {form.date} · {form.travelers} traveler{form.travelers > 1 ? "s" : ""}</p>
        <div style={{ background: "var(--cream)", borderRadius: "var(--radius-md)", padding: 20, marginBottom: 32, textAlign: "left" }}>
          <div style={{ fontWeight: 600, marginBottom: 8 }}>{pkg?.title}</div>
          <div style={{ fontSize: 13, color: "var(--brown-light)" }}>{pkg?.duration} · {agency?.name}</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 24, color: "var(--terracotta)", marginTop: 8 }}>₹{((pkg?.price || 0) * form.travelers).toLocaleString()}</div>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
          <button className="btn btn-primary" onClick={() => navigate("home")}>Explore More</button>
          <button className="btn btn-outline" onClick={() => navigate("chat", { agencyId: agency?.id })}>Chat with Agency</button>
        </div>
      </div>
    </div>
  );

  const totalPrice = (pkg?.price || 0) * form.travelers;

  return (
    <div style={{ paddingTop: 68, padding: "88px 24px 48px" }}>
      <div style={{ maxWidth: 860, margin: "0 auto" }}>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 32, marginBottom: 32 }}>Complete Your Booking</h1>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 32, alignItems: "start" }}>

          {/* Form */}
          <div className="card" style={{ padding: 32 }}>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 20, marginBottom: 24 }}>Traveler Details</h2>
            <div style={{ display: "grid", gap: 16 }}>
              {[
                { label: "Full Name *", key: "name", type: "text", placeholder: "Rahul Sharma" },
                { label: "Email Address *", key: "email", type: "email", placeholder: "rahul@gmail.com" },
                { label: "Phone Number", key: "phone", type: "tel", placeholder: "+91 98765 43210" },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6, color: "var(--brown-mid)" }}>{f.label}</label>
                  <input className="input" type={f.type} placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm(v => ({ ...v, [f.key]: e.target.value }))} />
                </div>
              ))}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Travelers</label>
                  <select className="input" value={form.travelers} onChange={e => setForm(v => ({ ...v, travelers: +e.target.value }))} style={{ padding: "12px 16px" }}>
                    {[1,2,3,4,5,6,7,8,9,10].map(n => <option key={n} value={n}>{n} person{n > 1 ? "s" : ""}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Travel Date *</label>
                  <input className="input" type="date" value={form.date} min={new Date().toISOString().split("T")[0]} onChange={e => setForm(v => ({ ...v, date: e.target.value }))} />
                </div>
              </div>
            </div>
          </div>

          {/* Summary */}
          <div>
            <div className="card" style={{ padding: 24, marginBottom: 16 }}>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: 18, marginBottom: 16 }}>Booking Summary</h2>
              {pkg && (
                <>
                  <Img src={pkg.img} alt={pkg.title} style={{ width: "100%", height: 120, objectFit: "cover", borderRadius: "var(--radius-md)", marginBottom: 16 }} />
                  <div style={{ fontWeight: 700, marginBottom: 4 }}>{pkg.title}</div>
                  <div style={{ fontSize: 13, color: "var(--brown-light)", marginBottom: 16 }}>⏱ {pkg.duration} · {agency?.name}</div>
                  <div style={{ display: "grid", gap: 8, borderTop: "1px solid var(--sand)", paddingTop: 16 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
                      <span>₹{pkg.price.toLocaleString()} × {form.travelers}</span>
                      <span>₹{(pkg.price * form.travelers).toLocaleString()}</span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: "var(--brown-light)" }}>
                      <span>Platform fee</span><span>₹0</span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 18, borderTop: "1px solid var(--sand)", paddingTop: 10, fontFamily: "var(--font-display)" }}>
                      <span>Total</span>
                      <span style={{ color: "var(--terracotta)" }}>₹{totalPrice.toLocaleString()}</span>
                    </div>
                  </div>
                </>
              )}
            </div>
            <button className="btn btn-primary btn-lg" style={{ width: "100%", justifyContent: "center" }} onClick={handleSubmit}>
              ✓ Confirm Booking
            </button>
            <p style={{ fontSize: 11, color: "var(--brown-light)", textAlign: "center", marginTop: 8 }}>Free cancellation within 24 hours</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── CHAT PAGE ────────────────────────────────────────────────────────────────
function ChatPage() {
  const { pageParams, user } = useApp();
  const agency = AGENCIES.find(a => a.id === pageParams.agencyId) || AGENCIES[0];
  const [messages, setMessages] = useState(CHAT_MESSAGES_DEFAULT);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (agency?.id) {
      messagesAPI.getAll(agency.id).then(msgs => {
        if (msgs?.length) setMessages(msgs.map(m => ({ id: m.id, from: m.from_agency ? "agency" : "user", text: m.content, time: new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) })));
      }).catch(() => {});
    }
  }, [agency?.id]);

  const scroll = () => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  useEffect(scroll, [messages]);

  const send = async () => {
    if (!input.trim() || sending) return;
    const text = input; setInput(""); setSending(true);
    const userMsg = { id: Date.now(), from: "user", text, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) };
    setMessages(m => [...m, userMsg]);
    try { await messagesAPI.send({ agency_id: agency.id, sender_name: user?.name || "Guest", content: text, from_agency: false }); } catch {}

    setTimeout(async () => {
      const replies = ["Thank you for reaching out! We'd be happy to customize a package for you.", "Our team is available 24/7. Could you share your preferred dates and budget?", "We have excellent packages for that destination. Let me pull up the details!", "We offer group discounts for 4+ travelers. Would you like more info?", "Our guide speaks 5 languages including English, Hindi & French. 😊"];
      const replyText = replies[Math.floor(Math.random() * replies.length)];
      const reply = { id: Date.now() + 1, from: "agency", text: replyText, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) };
      setMessages(m => [...m, reply]);
      try { await messagesAPI.send({ agency_id: agency.id, sender_name: agency.name, content: replyText, from_agency: true }); } catch {}
      setSending(false);
    }, 1200);
  };

  return (
    <div style={{ paddingTop: 68, height: "100vh", display: "flex", flexDirection: "column", background: "var(--cream)" }}>
      {/* Header */}
      <div style={{ background: "var(--forest-mid)", padding: "16px 24px", display: "flex", alignItems: "center", gap: 14, boxShadow: "var(--shadow-sm)" }}>
        <div style={{ width: 44, height: 44, borderRadius: "50%", overflow: "hidden", border: "2px solid rgba(255,255,255,0.3)" }}>
          <Img src={agency.img} alt={agency.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
        <div>
          <div style={{ fontWeight: 700, color: "#fff", fontSize: 16 }}>{agency.name}</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)", display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: "#7FE585", display: "inline-block" }} />
            Online · Usually replies in 5 min
          </div>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: 24, display: "flex", flexDirection: "column", gap: 12 }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ display: "flex", justifyContent: msg.from === "user" ? "flex-end" : "flex-start", gap: 10, alignItems: "flex-end" }}>
            {msg.from === "agency" && <Avatar initials={agency.name.slice(0,2).toUpperCase()} size={32} />}
            <div style={{
              maxWidth: "72%", padding: "12px 16px", borderRadius: msg.from === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
              background: msg.from === "user" ? "var(--forest-mid)" : "#fff",
              color: msg.from === "user" ? "#fff" : "var(--brown-dark)",
              boxShadow: "var(--shadow-sm)", lineHeight: 1.5, fontSize: 14,
            }}>
              {msg.text}
              <div style={{ fontSize: 10, marginTop: 4, opacity: 0.6, textAlign: "right" }}>{msg.time}</div>
            </div>
            {msg.from === "user" && <Avatar initials={user?.name?.slice(0,2) || "ME"} size={32} />}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick replies */}
      <div style={{ padding: "8px 24px", display: "flex", gap: 8, overflowX: "auto" }}>
        {["What packages do you offer?", "Do you offer group discounts?", "Is the price negotiable?"].map(q => (
          <button key={q} onClick={() => setInput(q)} style={{ flexShrink: 0, background: "#fff", border: "1px solid var(--sand)", borderRadius: 99, padding: "6px 14px", fontSize: 13, cursor: "pointer", color: "var(--brown-mid)", whiteSpace: "nowrap", fontFamily: "var(--font-body)" }}>{q}</button>
        ))}
      </div>

      {/* Input */}
      <div style={{ background: "#fff", padding: "16px 24px", borderTop: "1px solid var(--sand)", display: "flex", gap: 10 }}>
        <input className="input" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Type a message..." style={{ flex: 1 }} />
        <button className="btn btn-primary" onClick={send} style={{ borderRadius: "50%", width: 48, height: 48, padding: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>➤</button>
      </div>
    </div>
  );
}

// ─── REVIEWS SECTION ──────────────────────────────────────────────────────────
function ReviewsSection({ reviews, agencyId }) {
  const [newReview, setNewReview] = useState({ rating: 5, comment: "", user: "" });
  const [localReviews, setLocalReviews] = useState(reviews);
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = () => {
    if (!newReview.user || !newReview.comment) return;
    const r = { id: Date.now(), agencyId, user: newReview.user, avatar: newReview.user.slice(0,2).toUpperCase(), rating: newReview.rating, comment: newReview.comment, date: "Today" };
    setLocalReviews(v => [r, ...v]);
    setNewReview({ rating: 5, comment: "", user: "" });
    setShowForm(false);
  };

  const avg = localReviews.length ? (localReviews.reduce((s, r) => s + r.rating, 0) / localReviews.length).toFixed(1) : "0";

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 24, marginBottom: 32, flexWrap: "wrap" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 56, fontWeight: 900, color: "var(--brown-dark)", lineHeight: 1 }}>{avg}</div>
          <Stars rating={parseFloat(avg)} size={20} />
          <div style={{ color: "var(--brown-light)", fontSize: 13, marginTop: 4 }}>{localReviews.length} reviews</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>✍ Write a Review</button>
      </div>

      {showForm && (
        <div style={{ background: "var(--cream)", borderRadius: "var(--radius-lg)", padding: 24, marginBottom: 24 }}>
          <h3 style={{ fontFamily: "var(--font-display)", marginBottom: 16 }}>Add Your Review</h3>
          <input className="input" placeholder="Your name" value={newReview.user} onChange={e => setNewReview(v => ({ ...v, user: e.target.value }))} style={{ marginBottom: 12 }} />
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            {[1,2,3,4,5].map(n => (
              <button key={n} onClick={() => setNewReview(v => ({ ...v, rating: n }))} style={{ fontSize: 24, background: "none", border: "none", cursor: "pointer", color: n <= newReview.rating ? "var(--gold)" : "var(--sand)" }}>★</button>
            ))}
          </div>
          <textarea className="input" rows={3} placeholder="Share your experience..." value={newReview.comment} onChange={e => setNewReview(v => ({ ...v, comment: e.target.value }))} style={{ resize: "vertical", marginBottom: 12 }} />
          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn btn-primary" onClick={handleSubmit}>Submit Review</button>
            <button className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </div>
      )}

      {localReviews.map(r => (
        <div key={r.id} style={{ padding: "20px 0", borderBottom: "1px solid var(--sand)", display: "flex", gap: 14 }}>
          <Avatar initials={r.avatar} />
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, flexWrap: "wrap", gap: 8 }}>
              <span style={{ fontWeight: 600 }}>{r.user}</span>
              <span style={{ fontSize: 12, color: "var(--brown-light)" }}>{r.date}</span>
            </div>
            <Stars rating={r.rating} />
            <p style={{ marginTop: 8, lineHeight: 1.6, fontSize: 14, color: "var(--brown-mid)" }}>{r.comment}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── AUTH PAGE ────────────────────────────────────────────────────────────────
function AuthPage() {
  const { navigate, loginUser, registerUser, pageParams } = useApp();
  const [mode, setMode] = useState(pageParams.mode || "login");
  const [role, setRole] = useState("traveller");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (!form.email || !form.password) { setError("Please fill all fields"); return; }
    setLoading(true); setError("");
    try {
      if (mode === "login") {
        const u = await loginUser(form.email, form.password);
        navigate(u.role === "agency" ? "dashboard" : "home");
      } else {
        const u = await registerUser({ name: form.name || form.email.split("@")[0], email: form.email, password: form.password, role });
        navigate(u.role === "agency" ? "dashboard" : "home");
      }
    } catch (e) {
      setError(e.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ paddingTop: 68, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "url(https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&q=80&auto=format&fit=crop", position: "relative" }}>
      <div style={{ position: "absolute", inset: 0, background: "rgba(44,24,16,0.6)" }} />
      <div className="card fade-up" style={{ position: "relative", width: "min(90vw, 440px)", padding: 40 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>✈️</div>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 700 }}>
            {mode === "login" ? "Welcome Back!" : "Join TravelHub"}
          </h1>
          <p style={{ color: "var(--brown-light)", fontSize: 14, marginTop: 6 }}>
            {mode === "login" ? "Sign in to continue your journey" : "Create your free account"}
          </p>
        </div>

        {/* Role selector */}
        <div style={{ display: "flex", gap: 8, marginBottom: 24, background: "var(--cream)", borderRadius: "var(--radius-md)", padding: 4 }}>
          {["traveller", "agency"].map(r => (
            <button key={r} onClick={() => setRole(r)} style={{ flex: 1, padding: "10px 0", borderRadius: "var(--radius-sm)", border: "none", cursor: "pointer", fontFamily: "var(--font-body)", fontWeight: 600, fontSize: 14, transition: "all 0.2s", background: role === r ? "var(--forest-mid)" : "transparent", color: role === r ? "#fff" : "var(--brown-mid)" }}>
              {r === "traveller" ? "🧭 Traveller" : "🏢 Agency"}
            </button>
          ))}
        </div>

        <div style={{ display: "grid", gap: 14 }}>
          {mode === "register" && (
            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Full Name</label>
              <input className="input" placeholder="Rahul Sharma" value={form.name} onChange={e => setForm(v => ({ ...v, name: e.target.value }))} />
            </div>
          )}
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Email</label>
            <input className="input" type="email" placeholder="you@gmail.com" value={form.email} onChange={e => setForm(v => ({ ...v, email: e.target.value }))} />
          </div>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Password</label>
            <input className="input" type="password" placeholder="••••••••" value={form.password} onChange={e => setForm(v => ({ ...v, password: e.target.value }))} />
          </div>
        </div>

        <button className="btn btn-primary btn-lg" style={{ width: "100%", justifyContent: "center", marginTop: 24 }} onClick={handleSubmit} disabled={loading}>
          {loading ? "..." : mode === "login" ? "Sign In →" : "Create Account →"}
        </button>
        {error && <div style={{ background: "#FFE8E5", color: "var(--risk-high)", padding: "10px 16px", borderRadius: "var(--radius-sm)", marginTop: 12, fontSize: 14 }}>⚠️ {error}</div>}

        <p style={{ textAlign: "center", marginTop: 20, fontSize: 14, color: "var(--brown-light)" }}>
          {mode === "login" ? "Don't have an account? " : "Already have an account? "}
          <button onClick={() => setMode(mode === "login" ? "register" : "login")} style={{ color: "var(--forest-mid)", background: "none", border: "none", cursor: "pointer", fontWeight: 600, fontFamily: "var(--font-body)" }}>
            {mode === "login" ? "Sign up free" : "Sign in"}
          </button>
        </p>
      </div>
    </div>
  );
}

// ─── AGENCY DASHBOARD ─────────────────────────────────────────────────────────
function DashboardPage() {
  const { navigate, user, bookings } = useApp();
  const [activeTab, setActiveTab] = useState("overview");
  const [packages, setPackages] = useState(PACKAGES.slice(0, 2));
  const [showAddPkg, setShowAddPkg] = useState(false);
  const [newPkg, setNewPkg] = useState({ title: "", price: "", duration: "" });

  if (!user) return (
    <div style={{ paddingTop: 68, textAlign: "center", padding: "120px 24px" }}>
      <h2>Please sign in to access the dashboard</h2>
      <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => navigate("auth")}>Sign In</button>
    </div>
  );

  return (
    <div style={{ paddingTop: 68, minHeight: "100vh", display: "flex" }}>
      {/* Sidebar */}
      <div className="hide-mobile" style={{ width: 240, background: "var(--brown-dark)", position: "sticky", top: 68, height: "calc(100vh - 68px)", padding: "24px 0", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "0 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <Avatar initials={user.name.slice(0,2).toUpperCase()} size={48} />
          <div style={{ color: "#fff", fontWeight: 600, marginTop: 10 }}>{user.name}</div>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 12 }}>{user.role === "agency" ? "Agency Account" : "Traveller"}</div>
        </div>
        {[
          { id: "overview", icon: "📊", label: "Overview" },
          { id: "packages", icon: "📦", label: "Packages" },
          { id: "bookings", icon: "📅", label: "Bookings" },
          { id: "profile", icon: "👤", label: "Profile" },
        ].map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 20px", background: activeTab === t.id ? "rgba(255,255,255,0.1)" : "transparent", border: "none", color: activeTab === t.id ? "#fff" : "rgba(255,255,255,0.55)", cursor: "pointer", textAlign: "left", fontFamily: "var(--font-body)", fontSize: 14, borderLeft: activeTab === t.id ? "3px solid var(--gold-light)" : "3px solid transparent" }}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, padding: 32 }}>
        {activeTab === "overview" && (
          <div>
            <h1 style={{ fontFamily: "var(--font-display)", fontSize: 28, marginBottom: 8 }}>Welcome back, {user.name}! 👋</h1>
            <p style={{ color: "var(--brown-light)", marginBottom: 32 }}>Here's your activity overview</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 20, marginBottom: 40 }}>
              {[
                { icon: "📦", label: "Active Packages", value: packages.length, color: "var(--forest-mid)" },
                { icon: "📅", label: "Total Bookings", value: bookings.length, color: "var(--terracotta)" },
                { icon: "⭐", label: "Avg Rating", value: "4.8", color: "var(--gold)" },
                { icon: "💰", label: "Revenue", value: `₹${(bookings.reduce((s, b) => s + (b.pkg?.price || 0), 0)).toLocaleString()}`, color: "var(--sky)" },
              ].map(s => (
                <div key={s.label} className="card" style={{ padding: 24 }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>{s.icon}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 700, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 13, color: "var(--brown-light)" }}>{s.label}</div>
                </div>
              ))}
            </div>
            <div className="card" style={{ padding: 24 }}>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: 20, marginBottom: 16 }}>Recent Activity</h2>
              {bookings.length ? bookings.slice(-3).reverse().map(b => (
                <div key={b.id} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid var(--sand)", fontSize: 14 }}>
                  <div>
                    <div style={{ fontWeight: 600 }}>{b.form.name}</div>
                    <div style={{ color: "var(--brown-light)", fontSize: 12 }}>{b.pkg?.title} · {b.ts}</div>
                  </div>
                  <span className="badge badge-green">Confirmed</span>
                </div>
              )) : <p style={{ color: "var(--brown-light)" }}>No bookings yet. Share your profile to start receiving bookings!</p>}
            </div>
          </div>
        )}

        {activeTab === "packages" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 24, alignItems: "center" }}>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24 }}>Your Packages</h2>
              <button className="btn btn-primary" onClick={() => setShowAddPkg(true)}>+ Add Package</button>
            </div>
            {showAddPkg && (
              <div className="card" style={{ padding: 24, marginBottom: 24, border: "2px solid var(--forest-mid)" }}>
                <h3 style={{ fontFamily: "var(--font-display)", marginBottom: 16 }}>New Package</h3>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                  <input className="input" placeholder="Package Title" value={newPkg.title} onChange={e => setNewPkg(v => ({ ...v, title: e.target.value }))} />
                  <input className="input" placeholder="Price (₹)" type="number" value={newPkg.price} onChange={e => setNewPkg(v => ({ ...v, price: e.target.value }))} />
                  <input className="input" placeholder="Duration (e.g. 5 Days)" value={newPkg.duration} onChange={e => setNewPkg(v => ({ ...v, duration: e.target.value }))} />
                </div>
                <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
                  <button className="btn btn-primary" onClick={() => { if (newPkg.title) { setPackages(p => [...p, { ...newPkg, id: Date.now(), agencyId: 1, price: +newPkg.price, img: DESTINATIONS[0].img, type: "nature", inclusions: [], exclusions: [], itinerary: [] }]); setShowAddPkg(false); setNewPkg({ title: "", price: "", duration: "" }); } }}>Save</button>
                  <button className="btn btn-outline" onClick={() => setShowAddPkg(false)}>Cancel</button>
                </div>
              </div>
            )}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
              {packages.map(p => (
                <div key={p.id} className="card" style={{ overflow: "hidden" }}>
                  <Img src={p.img} alt={p.title} style={{ width: "100%", height: 140, objectFit: "cover" }} />
                  <div style={{ padding: 16 }}>
                    <div style={{ fontWeight: 700, marginBottom: 4 }}>{p.title}</div>
                    <div style={{ color: "var(--terracotta)", fontFamily: "var(--font-display)", fontSize: 20 }}>₹{p.price?.toLocaleString()}</div>
                    <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                      <button className="btn btn-outline btn-sm">Edit</button>
                      <button className="btn btn-sm" style={{ background: "#FFE8E5", color: "var(--risk-high)", border: "none" }} onClick={() => setPackages(prev => prev.filter(x => x.id !== p.id))}>Delete</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "bookings" && (
          <div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24, marginBottom: 24 }}>Bookings</h2>
            {bookings.length ? (
              <div className="card" style={{ overflow: "hidden" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ background: "var(--cream)" }}>
                      {["Traveler", "Package", "Date", "Travelers", "Total", "Status"].map(h => (
                        <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 12, fontWeight: 600, color: "var(--brown-light)", textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {bookings.map(b => (
                      <tr key={b.id} style={{ borderTop: "1px solid var(--sand)" }}>
                        <td style={{ padding: "14px 16px" }}><div style={{ fontWeight: 600, fontSize: 14 }}>{b.form.name}</div><div style={{ fontSize: 12, color: "var(--brown-light)" }}>{b.form.email}</div></td>
                        <td style={{ padding: "14px 16px", fontSize: 14 }}>{b.pkg?.title || "—"}</td>
                        <td style={{ padding: "14px 16px", fontSize: 14 }}>{b.form.date}</td>
                        <td style={{ padding: "14px 16px", fontSize: 14 }}>{b.form.travelers}</td>
                        <td style={{ padding: "14px 16px", fontSize: 14, fontWeight: 700, color: "var(--terracotta)" }}>₹{((b.pkg?.price || 0) * b.form.travelers).toLocaleString()}</td>
                        <td style={{ padding: "14px 16px" }}><span className="badge badge-green">Confirmed</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div style={{ textAlign: "center", padding: 60, color: "var(--brown-light)" }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>📅</div>
                <p>No bookings yet.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === "profile" && (
          <div style={{ maxWidth: 500 }}>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24, marginBottom: 24 }}>Profile Settings</h2>
            <div className="card" style={{ padding: 32 }}>
              <div style={{ display: "flex", gap: 16, alignItems: "center", marginBottom: 24 }}>
                <Avatar initials={user.name.slice(0,2).toUpperCase()} size={64} />
                <div>
                  <div style={{ fontWeight: 700, fontSize: 18 }}>{user.name}</div>
                  <div style={{ color: "var(--brown-light)", fontSize: 14 }}>{user.email}</div>
                  <span className="badge badge-green" style={{ marginTop: 4 }}>{user.role || "traveller"}</span>
                </div>
              </div>
              {[{ label: "Full Name", val: user.name }, { label: "Email", val: user.email }, { label: "Phone", val: "+91 98765 43210" }, { label: "Location", val: "Mumbai, India" }].map(f => (
                <div key={f.label} style={{ marginBottom: 16 }}>
                  <label style={{ fontSize: 13, fontWeight: 600, display: "block", marginBottom: 6 }}>{f.label}</label>
                  <input className="input" defaultValue={f.val} />
                </div>
              ))}
              <button className="btn btn-primary" style={{ marginTop: 8 }}>Save Changes</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── AGENCIES PAGE ────────────────────────────────────────────────────────────
function AgenciesPage() {
  const [search, setSearch] = useState("");
  const filtered = AGENCIES.filter(a =>
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.type.toLowerCase().includes(search.toLowerCase())
  );
  return (
    <div style={{ paddingTop: 68 }}>
      <div style={{ background: "var(--cream)", padding: "48px 24px", textAlign: "center", borderBottom: "1px solid var(--sand)" }}>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 40, fontWeight: 900, marginBottom: 12 }}>All Travel Agencies</h1>
        <p style={{ color: "var(--brown-light)", marginBottom: 24 }}>500+ verified agencies across India</p>
        <input className="input" style={{ maxWidth: 400, margin: "0 auto", display: "block" }} placeholder="Search agencies..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "40px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 24 }}>
          {filtered.map(a => <AgencyCard key={a.id} agency={a} />)}
        </div>
      </div>
      <Footer />
    </div>
  );
}

// ─── FOOTER ───────────────────────────────────────────────────────────────────
function Footer() {
  const { navigate } = useApp();
  return (
    <footer style={{ background: "var(--brown-dark)", color: "rgba(255,255,255,0.7)", padding: "64px 24px 32px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 40, marginBottom: 48 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
              <div style={{ width: 36, height: 36, background: "var(--forest-mid)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 18 }}>✈</div>
              <div style={{ fontFamily: "var(--font-display)", color: "#fff", fontWeight: 700, fontSize: 18 }}>TravelHub India</div>
            </div>
            <p style={{ lineHeight: 1.7, fontSize: 14 }}>India's most comprehensive multi-agency travel platform. Discover, compare, and book with confidence.</p>
          </div>
          {[
            { title: "Explore", links: ["Destinations", "Agencies", "Packages", "Map Explorer"] },
            { title: "Company", links: ["About Us", "Blog", "Careers", "Press"] },
            { title: "Support", links: ["Help Center", "Contact", "Safety", "Terms"] },
          ].map(col => (
            <div key={col.title}>
              <div style={{ color: "#fff", fontWeight: 600, marginBottom: 16, fontSize: 14, textTransform: "uppercase", letterSpacing: 1 }}>{col.title}</div>
              {col.links.map(l => <div key={l} style={{ marginBottom: 10, fontSize: 14, cursor: "pointer", transition: "color 0.2s" }} onMouseEnter={e => e.target.style.color = "#fff"} onMouseLeave={e => e.target.style.color = "rgba(255,255,255,0.7)"}>{l}</div>)}
            </div>
          ))}
        </div>
        {/* Map teaser in footer */}
        <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: "var(--radius-lg)", padding: 24, marginBottom: 32, display: "flex", alignItems: "center", gap: 24, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ color: "#fff", fontFamily: "var(--font-display)", fontSize: 18, marginBottom: 6 }}>📍 Find us across India</div>
            <p style={{ fontSize: 13 }}>Active in 28 states with 500+ partner agencies across every major destination.</p>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {["Delhi", "Mumbai", "Bangalore", "Chennai", "Kolkata", "Jaipur"].map(c => (
              <span key={c} className="badge" style={{ background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.8)" }}>{c}</span>
            ))}
          </div>
        </div>
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
          <div style={{ fontSize: 13 }}>© 2025 TravelHub India. Made with ❤️ for India's travelers.</div>
          <div style={{ display: "flex", gap: 16, fontSize: 13 }}>
            <span style={{ cursor: "pointer" }}>Privacy</span>
            <span style={{ cursor: "pointer" }}>Terms</span>
            <span style={{ cursor: "pointer" }}>Cookies</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── DESTINATION DETAIL PAGE ─────────────────────────────────────────────────
function DestinationDetailPage() {
  const { navigate, pageParams } = useApp();
  const dest = DESTINATIONS.find(d => d.id === pageParams.destId) || DESTINATIONS[0];
  const destAgencies = AGENCIES.filter(a => a.dest.includes(dest.id));
  const destPackages = PACKAGES.filter(p => p.destId === dest.id);
  const [lightbox, setLightbox] = useState(null);

  return (
    <div style={{ paddingTop: 68 }}>
      {/* Hero */}
      <div style={{ position: "relative", height: 420, overflow: "hidden" }}>
        <Img src={dest.img} alt={dest.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 30%, rgba(44,24,16,0.85))" }} />
        <div style={{ position: "absolute", bottom: 40, left: 40, right: 40 }}>
          <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
            <span className={`badge badge-${dest.type === "adventure" ? "terra" : dest.type === "beach" ? "blue" : "green"}`}>{dest.type}</span>
            <RiskBadge risk={dest.risk} />
            <span className="badge" style={{ background: "rgba(255,255,255,0.2)", color: "#fff" }}>📸 {dest.places?.length} Attractions</span>
          </div>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 900, color: "#fff", marginBottom: 8 }}>{dest.name}</h1>
          <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 16 }}>📍 {dest.state} · {dest.tagline}</div>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "48px 24px" }}>

        {/* About */}
        <div style={{ maxWidth: 760, marginBottom: 56 }}>
          <div className="badge badge-gold" style={{ marginBottom: 12 }}>About {dest.name}</div>
          <p style={{ fontSize: 16, lineHeight: 1.8, color: "var(--brown-mid)" }}>{dest.about}</p>
        </div>

        {/* PHOTO GALLERY — all tourist places */}
        <div style={{ marginBottom: 64 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 32 }}>
            <div>
              <div className="badge badge-terra" style={{ marginBottom: 10 }}>Tourist Places</div>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.2rem)", fontWeight: 700 }}>
                {dest.places?.length} Must-Visit Spots in {dest.name}
              </h2>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
            {(dest.places || []).map((place, i) => (
              <div key={i} onClick={() => setLightbox(place)} style={{ borderRadius: "var(--radius-lg)", overflow: "hidden", cursor: "zoom-in", boxShadow: "var(--shadow-sm)", transition: "all 0.3s", position: "relative" }} onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-6px)"; e.currentTarget.style.boxShadow = "var(--shadow-lg)"; }} onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "var(--shadow-sm)"; }}>
                <div style={{ paddingBottom: "70%", position: "relative" }}>
                  <Img src={place.img} alt={place.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(44,24,16,0.8) 0%, rgba(44,24,16,0) 50%)" }} />
                  <div style={{ position: "absolute", top: 12, right: 12, background: "rgba(0,0,0,0.4)", color: "#fff", fontSize: 11, padding: "4px 8px", borderRadius: 99, backdropFilter: "blur(4px)" }}>
                    🔍 View
                  </div>
                </div>
                <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "16px" }}>
                  <div style={{ color: "#fff", fontFamily: "var(--font-display)", fontSize: 16, fontWeight: 700, marginBottom: 4 }}>{place.name}</div>
                  <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, lineHeight: 1.5 }}>{place.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Lightbox */}
        {lightbox && (
          <>
            <div className="overlay" onClick={() => setLightbox(null)} />
            <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", zIndex: 1001, width: "min(92vw, 720px)", borderRadius: "var(--radius-xl)", overflow: "hidden", boxShadow: "0 24px 80px rgba(0,0,0,0.5)", animation: "fadeUp 0.25s ease" }}>
              <Img src={lightbox.img} alt={lightbox.name} style={{ width: "100%", maxHeight: "60vh", objectFit: "cover", display: "block" }} />
              <div style={{ background: "#fff", padding: "24px 28px" }}>
                <h3 style={{ fontFamily: "var(--font-display)", fontSize: 22, marginBottom: 8 }}>{lightbox.name}</h3>
                <p style={{ color: "var(--brown-light)", lineHeight: 1.7 }}>{lightbox.desc}</p>
                <button className="btn btn-outline btn-sm" style={{ marginTop: 16 }} onClick={() => setLightbox(null)}>✕ Close</button>
              </div>
            </div>
          </>
        )}

        {/* Packages */}
        {destPackages.length > 0 && (
          <div style={{ marginBottom: 56 }}>
            <div className="badge badge-green" style={{ marginBottom: 12 }}>Available Packages</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 700, marginBottom: 24 }}>Book a Trip to {dest.name}</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
              {destPackages.map(p => <PackageCard key={p.id} pkg={p} />)}
            </div>
          </div>
        )}

        {/* Agencies */}
        {destAgencies.length > 0 && (
          <div>
            <div className="badge badge-blue" style={{ marginBottom: 12 }}>Travel Agencies</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: 700, marginBottom: 24 }}>Agencies for {dest.name}</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
              {destAgencies.map(a => <AgencyCard key={a.id} agency={a} />)}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}

// ─── ALL DESTINATIONS PAGE ────────────────────────────────────────────────────
function DestinationsPage() {
  const { navigate } = useApp();
  const [filter, setFilter] = useState("all");
  const types = ["all", "heritage", "nature", "adventure", "beach", "spiritual"];
  const filtered = filter === "all" ? DESTINATIONS : DESTINATIONS.filter(d => d.type === filter);

  return (
    <div style={{ paddingTop: 68 }}>
      {/* Header */}
      <div style={{ background: "var(--cream)", padding: "56px 24px 40px", borderBottom: "1px solid var(--sand)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div className="badge badge-terra" style={{ marginBottom: 12 }}>Explore India</div>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 900, marginBottom: 8 }}>
            All Destinations
          </h1>
          <p style={{ color: "var(--brown-light)", marginBottom: 28 }}>{DESTINATIONS.length} destinations · 96 iconic tourist places with photos</p>
          {/* Type filters */}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {types.map(t => (
              <button key={t} onClick={() => setFilter(t)} className="btn btn-sm" style={{ borderRadius: 99, background: filter === t ? "var(--brown-dark)" : "#fff", color: filter === t ? "#fff" : "var(--brown-mid)", border: `1px solid ${filter === t ? "var(--brown-dark)" : "var(--sand)"}` }}>
                {t === "all" ? "🌍 All" : t === "heritage" ? "🛕 Heritage" : t === "nature" ? "🌿 Nature" : t === "adventure" ? "🏔 Adventure" : t === "beach" ? "🏖 Beach" : "🙏 Spiritual"}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1300, margin: "0 auto", padding: "48px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 28 }}>
          {filtered.map(d => (
            <div key={d.id} className="card" onClick={() => navigate("destination", { destId: d.id })} style={{ cursor: "pointer" }}>
              {/* Cover */}
              <div style={{ position: "relative", paddingBottom: "56%", overflow: "hidden" }}>
                <Img src={d.img} alt={d.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.5s" }} onMouseEnter={e => e.target.style.transform = "scale(1.07)"} onMouseLeave={e => e.target.style.transform = "scale(1)"} />
                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(44,24,16,0.75) 0%, transparent 55%)" }} />
                <div style={{ position: "absolute", bottom: 16, left: 16 }}>
                  <h3 style={{ color: "#fff", fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 700 }}>{d.name}</h3>
                  <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 13 }}>📍 {d.state}</div>
                </div>
                <div style={{ position: "absolute", top: 12, right: 12 }}>
                  <RiskBadge risk={d.risk} />
                </div>
                <div style={{ position: "absolute", top: 12, left: 12, background: "rgba(0,0,0,0.45)", color: "#fff", fontSize: 12, padding: "4px 10px", borderRadius: 99, backdropFilter: "blur(4px)" }}>
                  📸 {d.places?.length} places
                </div>
              </div>
              {/* Place thumbnail strip */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 2, padding: "2px 0" }}>
                {(d.places || []).slice(0, 4).map((p, i) => (
                  <div key={i} style={{ paddingBottom: "70%", position: "relative", overflow: "hidden" }}>
                    <Img src={p.img} alt={p.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
                  </div>
                ))}
              </div>
              {/* Info */}
              <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontSize: 13, color: "var(--brown-light)", marginBottom: 6 }}>{d.tagline}</div>
                  <span className={`badge badge-${d.type === "adventure" ? "terra" : d.type === "beach" ? "blue" : "green"}`}>{d.type}</span>
                </div>
                <button className="btn btn-primary btn-sm">Explore →</button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}

// ─── AI SEARCH PAGE ───────────────────────────────────────────────────────────
function AISearchPage() {
  const { navigate } = useApp();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true); setError(""); setResults(null);
    try {
      const res = await aiSearchAPI.search(query);
      setResults(res);
    } catch (e) {
      setError("AI Search requires the backend to be running. " + e.message);
    } finally { setLoading(false); }
  };

  const examples = [
    "5-day trip to Manali under ₹15,000 for 2 people",
    "honeymoon package in Goa in December",
    "adventure trek for solo traveler under 7 days",
    "family trip to Kerala, budget around ₹25,000",
  ];

  return (
    <div style={{ paddingTop: 68, minHeight: "100vh" }}>
      <div style={{ background: "linear-gradient(135deg, var(--brown-dark), var(--forest))", padding: "64px 24px", textAlign: "center" }}>
        <div className="badge badge-gold" style={{ marginBottom: 16, display: "inline-flex" }}>✨ Powered by Gemini AI</div>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3rem)", color: "#fff", marginBottom: 12 }}>AI Travel Search</h1>
        <p style={{ color: "rgba(255,255,255,0.75)", marginBottom: 32, maxWidth: 560, margin: "0 auto 32px" }}>
          Describe your dream trip in plain English — our AI finds the perfect packages for you.
        </p>
        <div style={{ display: "flex", gap: 8, maxWidth: 640, margin: "0 auto 20px", background: "rgba(255,255,255,0.95)", borderRadius: "var(--radius-xl)", padding: "8px 8px 8px 20px" }}>
          <span style={{ fontSize: 20, alignSelf: "center" }}>🤖</span>
          <input className="input" style={{ border: "none", background: "transparent", flex: 1, fontSize: 16 }}
            placeholder="e.g. 5-day trip to Goa under ₹12,000 for couple..."
            value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSearch()} />
          <button className="btn btn-primary" onClick={handleSearch} disabled={loading} style={{ borderRadius: "var(--radius-xl)" }}>
            {loading ? "Searching..." : "Search ✨"}
          </button>
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
          {examples.map(ex => (
            <button key={ex} onClick={() => { setQuery(ex); }} style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.25)", color: "#fff", padding: "6px 14px", borderRadius: 99, fontSize: 12, cursor: "pointer", fontFamily: "var(--font-body)" }}>{ex}</button>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px" }}>
        {error && <div style={{ background: "#FFE8E5", color: "var(--risk-high)", padding: 20, borderRadius: "var(--radius-md)", marginBottom: 24 }}>⚠️ {error}</div>}
        {loading && <Loader />}
        {results && (
          <div>
            <div style={{ background: "var(--cream)", borderRadius: "var(--radius-lg)", padding: 20, marginBottom: 32 }}>
              <div style={{ fontWeight: 600, marginBottom: 8 }}>🤖 AI Summary</div>
              <p style={{ color: "var(--brown-mid)" }}>{results.summary}</p>
              {results.parsed_filters && (
                <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
                  {results.parsed_filters.destination && <span className="badge badge-green">📍 {results.parsed_filters.destination}</span>}
                  {results.parsed_filters.max_price && <span className="badge badge-gold">💰 Under ₹{results.parsed_filters.max_price.toLocaleString()}</span>}
                  {results.parsed_filters.package_type && <span className="badge badge-terra">🏷 {results.parsed_filters.package_type}</span>}
                  {results.parsed_filters.people_count && <span className="badge badge-blue">👥 {results.parsed_filters.people_count} people</span>}
                </div>
              )}
            </div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 22, marginBottom: 20 }}>{results.total_found} Packages Found</h2>
            <div style={{ display: "grid", gap: 16 }}>
              {results.results.map(pkg => (
                <div key={pkg.id} className="card" style={{ padding: 24, display: "flex", gap: 20, alignItems: "flex-start", cursor: "pointer" }} onClick={() => navigate("package", { packageId: pkg.id })}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                      <h3 style={{ fontFamily: "var(--font-display)", fontSize: 18 }}>{pkg.title}</h3>
                      <div style={{ background: pkg.match_score >= 70 ? "var(--forest-mid)" : "var(--gold)", color: "#fff", borderRadius: 99, padding: "4px 12px", fontSize: 13, fontWeight: 700, flexShrink: 0 }}>
                        {pkg.match_score}% match
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 12, fontSize: 13, color: "var(--brown-light)", marginBottom: 12 }}>
                      <span>📍 {pkg.destination}</span>
                      <span>⏱ {pkg.duration}</span>
                      <span>👥 Max {pkg.max_people}</span>
                    </div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {pkg.match_reasons.map((r, i) => <span key={i} style={{ fontSize: 12, color: "var(--forest-mid)", background: "#E8F5E3", padding: "3px 10px", borderRadius: 99 }}>✓ {r}</span>)}
                    </div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ fontFamily: "var(--font-display)", fontSize: 24, fontWeight: 700, color: "var(--terracotta)" }}>₹{pkg.base_price.toLocaleString()}</div>
                    <div style={{ fontSize: 12, color: "var(--brown-light)" }}>per person</div>
                    <button className="btn btn-primary btn-sm" style={{ marginTop: 8 }}>Book Now</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {!results && !loading && !error && (
          <div style={{ textAlign: "center", padding: "60px 24px", color: "var(--brown-light)" }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>🤖</div>
            <p style={{ fontSize: 18 }}>Type your travel dream above and let AI find the perfect match!</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── TRAVEL DNA QUIZ PAGE ─────────────────────────────────────────────────────
function DNAQuizPage() {
  const { navigate } = useApp();
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState(0);

  useEffect(() => {
    dnaAPI.getQuestions().then(d => setQuestions(d.questions || [])).catch(() => {
      // Fallback questions if backend offline
      setQuestions([
        { id: "budget_style", question: "What is your travel budget style?", options: [{ value: "backpacker", label: "Backpacker", hint: "Under ₹10,000" }, { value: "midrange", label: "Mid-range", hint: "₹10,000–₹30,000" }, { value: "luxury", label: "Luxury", hint: "₹30,000+" }] },
        { id: "activity_level", question: "How active do you like your trips?", options: [{ value: "relaxed", label: "Relaxed", hint: "Beaches, leisure" }, { value: "moderate", label: "Moderate", hint: "Some hiking" }, { value: "intense", label: "Intense", hint: "Trekking, camping" }] },
        { id: "travel_group", question: "Who do you travel with?", options: [{ value: "solo", label: "Solo", hint: "Just me" }, { value: "couple", label: "Couple", hint: "Me and my partner" }, { value: "family", label: "Family", hint: "With kids" }, { value: "friends", label: "Friends", hint: "The whole gang" }] },
        { id: "vibe", question: "What is your travel vibe?", options: [{ value: "adventure", label: "Adventure", hint: "Thrills" }, { value: "culture", label: "Culture", hint: "Heritage" }, { value: "beach", label: "Beach", hint: "Sun & sea" }, { value: "nature", label: "Nature", hint: "Wildlife" }] },
        { id: "duration", question: "How long do you like your trips?", options: [{ value: "weekend", label: "Weekend", hint: "2–3 days" }, { value: "short", label: "Short trip", hint: "3–5 days" }, { value: "week", label: "A week", hint: "6–8 days" }, { value: "long", label: "Long trip", hint: "9+ days" }] },
      ]);
    });
  }, []);

  const currentQ = questions[step];
  const totalSteps = questions.length;
  const progress = totalSteps ? ((step) / totalSteps) * 100 : 0;

  const handleAnswer = (val) => {
    const newAnswers = { ...answers, [currentQ.id]: val };
    setAnswers(newAnswers);
    if (step < totalSteps - 1) {
      setStep(s => s + 1);
    } else {
      submitQuiz(newAnswers);
    }
  };

  const submitQuiz = async (finalAnswers) => {
    setLoading(true); setError("");
    try {
      const res = await dnaAPI.submitQuiz(finalAnswers);
      setResult(res);
    } catch (e) {
      setError("Quiz requires the backend. " + e.message);
      setLoading(false);
    }
  };

  if (result) return (
    <div style={{ paddingTop: 68, minHeight: "100vh", background: "var(--cream)", padding: "88px 24px 48px" }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <div className="card" style={{ padding: 40, textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 72, marginBottom: 16 }}>{result.persona.emoji}</div>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: 36, marginBottom: 8 }}>You're a {result.persona.name}!</h1>
          <p style={{ color: "var(--brown-light)", fontSize: 18, marginBottom: 20 }}>{result.persona.tagline}</p>
          <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", marginBottom: 24 }}>
            {result.persona.traits.map(t => <span key={t} className="badge badge-gold">{t}</span>)}
          </div>
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 12, color: "var(--brown-light)" }}>Budget Range</div><div style={{ fontWeight: 600 }}>{result.persona.budget_range}</div></div>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 12, color: "var(--brown-light)" }}>Ideal Duration</div><div style={{ fontWeight: 600 }}>{result.persona.ideal_duration}</div></div>
          </div>
        </div>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: 24, marginBottom: 20 }}>Your Matched Packages ({result.total_packages})</h2>
        <div style={{ display: "grid", gap: 16 }}>
          {result.matched_packages.slice(0, 5).map(pkg => (
            <div key={pkg.id} className="card" style={{ padding: 20, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, cursor: "pointer" }} onClick={() => navigate("package", { packageId: pkg.id })}>
              <div>
                <h3 style={{ fontFamily: "var(--font-display)", fontSize: 16, marginBottom: 4 }}>{pkg.title}</h3>
                <div style={{ fontSize: 13, color: "var(--brown-light)", marginBottom: 8 }}>📍 {pkg.destination} · ⏱ {pkg.duration}</div>
                <div style={{ fontSize: 12, color: "var(--forest-mid)", background: "#E8F5E3", padding: "4px 10px", borderRadius: 99, display: "inline-block" }}>
                  {pkg.match_score}% match — {pkg.why_matched}
                </div>
              </div>
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "var(--terracotta)", fontWeight: 700 }}>₹{pkg.base_price.toLocaleString()}</div>
                <button className="btn btn-primary btn-sm" style={{ marginTop: 8 }}>Book</button>
              </div>
            </div>
          ))}
        </div>
        <div style={{ textAlign: "center", marginTop: 32 }}>
          <button className="btn btn-outline" onClick={() => { setResult(null); setStep(0); setAnswers({}); }}>Retake Quiz</button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ paddingTop: 68, minHeight: "100vh", background: "linear-gradient(135deg, var(--brown-dark), var(--forest))", display: "flex", alignItems: "center", justifyContent: "center", padding: "88px 24px 48px" }}>
      <div style={{ width: "min(92vw, 560px)" }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🧬</div>
          <h1 style={{ fontFamily: "var(--font-display)", color: "#fff", fontSize: 28, marginBottom: 8 }}>Travel DNA Quiz</h1>
          <p style={{ color: "rgba(255,255,255,0.7)" }}>Discover your traveler persona and get personalized packages</p>
        </div>

        {/* Progress bar */}
        <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 99, height: 6, marginBottom: 32 }}>
          <div style={{ background: "var(--gold-light)", borderRadius: 99, height: "100%", width: `${progress}%`, transition: "width 0.4s ease" }} />
        </div>

        {error && <div style={{ background: "rgba(255,80,80,0.2)", color: "#fff", padding: 16, borderRadius: "var(--radius-md)", marginBottom: 16 }}>⚠️ {error}</div>}
        {loading && <div style={{ textAlign: "center", color: "#fff", padding: 40 }}><Loader /><p style={{ marginTop: 16 }}>Finding your perfect matches...</p></div>}

        {currentQ && !loading && (
          <div className="card" style={{ padding: 32 }}>
            <div style={{ fontSize: 12, color: "var(--brown-light)", marginBottom: 8 }}>Question {step + 1} of {totalSteps}</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: 22, marginBottom: 24 }}>{currentQ.question}</h2>
            <div style={{ display: "grid", gap: 12 }}>
              {currentQ.options.map(opt => (
                <button key={opt.value} onClick={() => handleAnswer(opt.value)} style={{
                  padding: "16px 20px", borderRadius: "var(--radius-md)", border: "2px solid var(--sand)",
                  background: answers[currentQ.id] === opt.value ? "var(--forest-mid)" : "#fff",
                  color: answers[currentQ.id] === opt.value ? "#fff" : "var(--brown-dark)",
                  cursor: "pointer", textAlign: "left", fontFamily: "var(--font-body)", transition: "all 0.2s",
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                }}>
                  <span style={{ fontWeight: 600 }}>{opt.label}</span>
                  <span style={{ fontSize: 13, opacity: 0.7 }}>{opt.hint}</span>
                </button>
              ))}
            </div>
            {step > 0 && <button className="btn btn-outline btn-sm" style={{ marginTop: 20 }} onClick={() => setStep(s => s - 1)}>← Back</button>}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── TRIP ROOM PAGE (Group Trip Planner) ──────────────────────────────────────
function TripRoomPage() {
  const { user, navigate } = useApp();
  const [view, setView] = useState("home"); // home | create | join | room
  const [roomCode, setRoomCode] = useState("");
  const [roomName, setRoomName] = useState("");
  const [roomData, setRoomData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const wsRef = useRef(null);

  const handleCreate = async () => {
    if (!user) { navigate("auth"); return; }
    if (!roomName.trim()) return;
    setLoading(true); setError("");
    try {
      const res = await tripRoomAPI.create({ name: roomName });
      setRoomCode(res.room_code);
      await loadRoom(res.room_code);
      setView("room");
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  };

  const handleJoin = async () => {
    if (!user) { navigate("auth"); return; }
    if (!roomCode.trim()) return;
    setLoading(true); setError("");
    try {
      await tripRoomAPI.join(roomCode.toUpperCase());
      await loadRoom(roomCode.toUpperCase());
      setView("room");
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  };

  const loadRoom = async (code) => {
    const data = await tripRoomAPI.getRoom(code);
    setRoomData(data);
  };

  const handleVote = async (packageId) => {
    try {
      const res = await tripRoomAPI.vote(roomData.room_code, packageId);
      setRoomData(d => ({ ...d, packages: res.current_results, votes_cast: (d.votes_cast || 0) + 1 }));
    } catch (e) { setError(e.message); }
  };

  if (view === "room" && roomData) return (
    <div style={{ paddingTop: 68, minHeight: "100vh", padding: "88px 24px 48px" }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32, flexWrap: "wrap", gap: 16 }}>
          <div>
            <h1 style={{ fontFamily: "var(--font-display)", fontSize: 28 }}>{roomData.name} 🏕️</h1>
            <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
              <span className="badge badge-green">👥 {roomData.total_members} members</span>
              <span className="badge badge-gold">🗳️ {roomData.votes_cast} votes</span>
              <span className="badge badge-blue" style={{ cursor: "pointer" }} onClick={() => navigator.clipboard.writeText(roomData.room_code)}>📋 Code: {roomData.room_code}</span>
            </div>
          </div>
          {error && <div style={{ color: "var(--risk-high)", fontSize: 13 }}>⚠️ {error}</div>}
        </div>

        {roomData.packages.length === 0 ? (
          <div style={{ textAlign: "center", padding: 60, color: "var(--brown-light)" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📦</div>
            <p>No packages added yet. The room creator needs to add packages for voting.</p>
          </div>
        ) : (
          <div style={{ display: "grid", gap: 16 }}>
            {roomData.packages.map(pkg => (
              <div key={pkg.package_id} className="card" style={{ padding: 24, border: pkg.is_winner ? "2px solid var(--gold)" : "none" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                      {pkg.is_winner && <span style={{ fontSize: 20 }}>🏆</span>}
                      <h3 style={{ fontFamily: "var(--font-display)", fontSize: 18 }}>{pkg.title}</h3>
                    </div>
                    <div style={{ fontSize: 13, color: "var(--brown-light)", marginBottom: 12 }}>📍 {pkg.destination} · ₹{pkg.base_price.toLocaleString()} · {pkg.duration}</div>
                    <div style={{ background: "var(--cream)", borderRadius: "var(--radius-sm)", height: 8, marginBottom: 8 }}>
                      <div style={{ background: pkg.is_winner ? "var(--gold)" : "var(--forest-mid)", borderRadius: "var(--radius-sm)", height: "100%", width: `${roomData.total_members ? (pkg.vote_count / roomData.total_members) * 100 : 0}%`, transition: "width 0.5s ease" }} />
                    </div>
                    <div style={{ fontSize: 13, color: "var(--brown-light)" }}>{pkg.vote_count} vote{pkg.vote_count !== 1 ? "s" : ""} · {pkg.voters.join(", ") || "No votes yet"}</div>
                  </div>
                  <button className="btn btn-primary btn-sm" onClick={() => handleVote(pkg.package_id)}>
                    Vote 🗳️
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div style={{ paddingTop: 68, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--cream)" }}>
      <div style={{ textAlign: "center", maxWidth: 560, padding: 24 }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>🏕️</div>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 36, marginBottom: 12 }}>Group Trip Planner</h1>
        <p style={{ color: "var(--brown-light)", marginBottom: 40 }}>Create a room, invite friends, add packages, and vote on where to go together — in real time!</p>
        {error && <div style={{ background: "#FFE8E5", color: "var(--risk-high)", padding: 16, borderRadius: "var(--radius-md)", marginBottom: 16 }}>⚠️ {error}</div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>
          <div className="card" style={{ padding: 28 }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>✨</div>
            <h3 style={{ fontFamily: "var(--font-display)", marginBottom: 12 }}>Create Room</h3>
            <input className="input" placeholder="Room name e.g. Goa 2025" value={roomName} onChange={e => setRoomName(e.target.value)} style={{ marginBottom: 12 }} />
            <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center" }} onClick={handleCreate} disabled={loading}>
              {loading ? "Creating..." : "Create Room"}
            </button>
          </div>
          <div className="card" style={{ padding: 28 }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>🔗</div>
            <h3 style={{ fontFamily: "var(--font-display)", marginBottom: 12 }}>Join Room</h3>
            <input className="input" placeholder="6-char room code" value={roomCode} onChange={e => setRoomCode(e.target.value.toUpperCase())} style={{ marginBottom: 12, textTransform: "uppercase", letterSpacing: 2 }} />
            <button className="btn btn-outline" style={{ width: "100%", justifyContent: "center" }} onClick={handleJoin} disabled={loading}>
              {loading ? "Joining..." : "Join Room"}
            </button>
          </div>
        </div>
        <p style={{ fontSize: 13, color: "var(--brown-light)" }}>⚡ Requires login and backend to be running</p>
      </div>
    </div>
  );
}

// ─── ROUTER ───────────────────────────────────────────────────────────────────
function Router() {
  const { page } = useApp();
  const pages = {
    home: <HomePage />,
    search: <SearchPage />,
    agencies: <AgenciesPage />,
    agency: <AgencyDetailPage />,
    package: <PackageDetailPage />,
    booking: <BookingPage />,
    chat: <ChatPage />,
    auth: <AuthPage />,
    dashboard: <DashboardPage />,
    map: <MapPage />,
    destination: <DestinationDetailPage />,
    destinations: <DestinationsPage />,
    aisearch: <AISearchPage />,
    dna: <DNAQuizPage />,
    triproom: <TripRoomPage />,
  };
  return pages[page] || <HomePage />;
}

// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────
function NotificationStack() {
  const { notifications } = useApp();
  return (
    <div style={{ position: "fixed", bottom: 80, right: 24, zIndex: 9998, display: "flex", flexDirection: "column", gap: 8 }}>
      {notifications.map(n => <Notification key={n.id} msg={n.msg} />)}
    </div>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function TravelHubApp() {
  return (
    <>
      <GlobalStyles />
      <AppProvider>
        <AppInner />
      </AppProvider>
    </>
  );
}

function AppInner() {
  const { isOffline, page } = useApp();
  return (
    <>
      {page !== "chat" && <Navbar />}
      <Router />
      <NotificationStack />
      {isOffline && (
        <div className="offline-bar">
          📡 <strong>You're Offline</strong> — Showing cached results. Some features may be unavailable.
        </div>
      )}
    </>
  );
}
